"""Release identity used by launchers, diagnostics and the desktop window."""
VERSION = "31.47.4"
RELEASE_NAME = "DEPENDENCY ALERT FIXES"
SOURCE_FILENAME = "EDIE_31_47_1_IMPROVED.py"
MINIMUM_PYTHON = (3, 11)
