"""Read Ollama's model inventory and describe status probe failures."""

import json
from urllib.error import HTTPError, URLError
import urllib.request


def read_model_list(url, timeout=4.0):
    request = urllib.request.Request(url, headers={'Accept': 'application/json'})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        payload = json.loads(response.read(2_000_000).decode('utf-8', 'replace'))
    if not isinstance(payload, dict) or not isinstance(payload.get('models'), list):
        raise ValueError('Ollama returned an invalid model list')
    return [item for item in payload['models'] if isinstance(item, dict)]


def describe_status_failure(error):
    if isinstance(error, HTTPError):
        return 'error', f'Ollama status check returned HTTP {error.code}'
    reason = error.reason if isinstance(error, URLError) else error
    windows_code = getattr(reason, 'winerror', None)
    if isinstance(reason, TimeoutError) or windows_code == 10060:
        return 'timed_out', 'Ollama status check timed out'
    if isinstance(reason, ConnectionRefusedError) or windows_code == 10061:
        return 'offline', 'Ollama offline'
    return 'error', 'Could not check Ollama status'
