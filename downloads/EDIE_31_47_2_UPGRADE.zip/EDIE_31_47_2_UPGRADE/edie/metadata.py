"""Release identity used by launchers, diagnostics and the desktop window."""
VERSION = "31.47.2"
RELEASE_NAME = "LOCAL AI MODEL LAB FIX"
SOURCE_FILENAME = "EDIE_31_47_1_IMPROVED.py"
MINIMUM_PYTHON = (3, 11)
