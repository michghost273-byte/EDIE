"""Track profile-owned operations so a UI switch cannot redirect an active job."""
from contextlib import contextmanager
import threading

_registry_lock = threading.RLock()


def active_profile_name(app):
    return str(getattr(app, 'active_profile', 'Default') or 'Default')


def service_profile(service):
    """Look up the current profile for a service attached to the app."""
    return active_profile_name(service.app)


@contextmanager
def profile_operation(app, profile, operation_id):
    with _registry_lock:
        jobs = getattr(app, '_edie47_active_jobs', None)
        if jobs is None:
            jobs = {}
            app._edie47_active_jobs = jobs
        key = (threading.get_ident(), str(operation_id))
        jobs[key] = str(profile)
    try:
        yield str(profile)
    finally:
        with _registry_lock:
            jobs.pop(key, None)


def profile_changed(app, owner):
    return active_profile_name(app) != str(owner)
