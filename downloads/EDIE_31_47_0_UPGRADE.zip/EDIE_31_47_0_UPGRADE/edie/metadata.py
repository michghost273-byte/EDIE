"""Release identity used by launchers, diagnostics and the desktop window."""
VERSION = "31.47.0"
RELEASE_NAME = "RELIABILITY & VOICE UPGRADE"
SOURCE_FILENAME = "EDIE_31_47_0_IMPROVED.py"
MINIMUM_PYTHON = (3, 11)
