"""Release identity used by launchers, diagnostics and the desktop window."""
VERSION = "31.47.3"
RELEASE_NAME = "VISION AND DIAGNOSTICS FIXES"
SOURCE_FILENAME = "EDIE_31_47_1_IMPROVED.py"
MINIMUM_PYTHON = (3, 11)
