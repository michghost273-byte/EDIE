#!/usr/bin/env python3
"""Stable EDIE launcher. Optional voice packages are not required to start chat."""
import sys

if sys.version_info < (3, 11):
    print('EDIE needs Python 3.11 or newer. Set EDIE_PYTHON to a supported Python installation.', file=sys.stderr)
    raise SystemExit(2)

from edie.launcher import main

if __name__ == '__main__':
    raise SystemExit(main())
