from contextlib import closing
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest

from edie.retrieval import candidate_rows, document_chunks, ensure_schema, vector_metadata


class RetrievalTests(unittest.TestCase):
    def database(self):
        conn = sqlite3.connect(':memory:')
        self.addCleanup(conn.close)
        conn.row_factory = sqlite3.Row
        conn.executescript('''CREATE TABLE memories(id INTEGER PRIMARY KEY,profile TEXT,content TEXT,embedding TEXT DEFAULT '');
            CREATE TABLE documents(id INTEGER PRIMARY KEY,profile TEXT,chunk TEXT,embedding TEXT DEFAULT '');''')
        ensure_schema(conn)
        return conn

    def test_search_triggers_and_profiles(self):
        conn = self.database()
        conn.executemany('INSERT INTO memories(profile,content) VALUES(?,?)', [('A','unusualkeyword EDIE'), ('B','unusualkeyword other profile')])
        rows = candidate_rows(conn, 'memories', 'A', 'unusualkeyword')
        self.assertEqual([row['content'] for row in rows], ['unusualkeyword EDIE'])
        conn.execute("UPDATE memories SET content='replacementkeyword' WHERE profile='A'")
        self.assertEqual(candidate_rows(conn, 'memories', 'A', 'replacementkeyword')[0]['content'], 'replacementkeyword')
        conn.execute("DELETE FROM memories WHERE profile='A'")
        self.assertEqual(candidate_rows(conn, 'memories', 'A', 'replacementkeyword'), [])

    def test_vectors_are_never_mixed_between_models(self):
        conn = self.database()
        conn.execute('INSERT INTO memories(profile,content,embedding,embedding_model) VALUES(?,?,?,?)', ('A','EDIE vector','[1,0]','old-model'))
        row = candidate_rows(conn, 'memories', 'A', 'EDIE', 'new-model')[0]
        self.assertEqual(row['embedding'], '')
        row = candidate_rows(conn, 'memories', 'A', 'EDIE', 'old-model')[0]
        self.assertEqual(row['embedding'], '[1,0]')

    def test_chunk_offsets_preserve_original_text_and_overlap(self):
        text = 'A document sentence with meaningful words. ' * 100
        chunks = list(document_chunks(text, 500, 80))
        self.assertGreater(len(chunks), 1)
        for chunk in chunks:
            self.assertEqual(chunk['text'], text[chunk['start']:chunk['end']])
            self.assertLessEqual(len(chunk['text']), 500)
        self.assertLess(chunks[1]['start'], chunks[0]['end'])

    def test_non_finite_vectors_are_rejected(self):
        with self.assertRaises(ValueError):
            vector_metadata([1, float('nan')], 'model')
        self.assertEqual(vector_metadata([1, 0], 'model')[2], 2)
