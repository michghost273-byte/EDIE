import contextlib
import importlib.util
from io import StringIO
import json
import os
from pathlib import Path
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from edie.metadata import SOURCE_FILENAME


class ApplicationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.module_data = tempfile.TemporaryDirectory()
        source = Path(__file__).resolve().parents[1] / SOURCE_FILENAME
        with patch.dict(os.environ, {'EDIE_DATA_DIR': cls.module_data.name}):
            spec = importlib.util.spec_from_file_location('edie_upgrade_test_application', source)
            cls.module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(cls.module)

    @classmethod
    def tearDownClass(cls):
        cls.module_data.cleanup()

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    def app(self):
        app = SimpleNamespace(active_profile='Default', _closing=False, _lockdown_active=False)
        app.store = self.module.EDIEStore(Path(self.tmp.name) / 'test.sqlite3')
        class Coordinator:
            def learned_summary(self): return {}
            def _step(self, kind, objective):
                return {'checks': [{'status':'error','error':'Simulated failed check'}]}
        app._edie42_coordinator = Coordinator()
        return app

    def test_malformed_performance_modes_do_not_block_startup(self):
        path = Path(self.tmp.name) / 'edie46_performance.json'
        for modes in ([], None, 7, {'Default': []}, {'Default': {'bad':'shape'}}):
            path.write_text(json.dumps({'modes': modes}))
            perf = self.module.EDIE46Performance(SimpleNamespace(active_profile='Default'), self.tmp.name)
            self.assertEqual(perf.mode(), 'Balanced')

    def test_health_failures_are_not_reported_as_completed(self):
        app = self.app()
        core = self.module.EDIE45Automation(app)
        job = core.prepare('Check EDIE local health', option='quick')
        result = core.run(job['id'])
        self.assertEqual(result['state'], 'partial')
        self.assertEqual(result['receipts'][0]['state'], 'partial')
        self.assertEqual(app._edie47_active_jobs, {})

    def test_profile_change_cancels_the_original_job_without_cross_profile_receipts(self):
        app = self.app()
        def step(kind, objective):
            app.active_profile = 'Other'
            return {'ok': True}
        app._edie42_coordinator._step = step
        core = self.module.EDIE45Automation(app)
        job = core.prepare('Check EDIE local health', option='quick')
        result = core.run(job['id'])
        self.assertEqual(result['state'], 'cancelled')
        self.assertEqual(result['receipts'], [])
        with app.store._db() as db:
            saved = db.execute('SELECT profile,state FROM e45_jobs WHERE id=?', (job['id'],)).fetchone()
            self.assertEqual(tuple(saved), ('Default', 'cancelled'))
            self.assertEqual(db.execute('SELECT count(*) FROM e45_receipts').fetchone()[0], 0)

    def test_voice_does_not_replay_an_old_answer(self):
        app = self.app()
        callbacks = []
        app.root = SimpleNamespace(after=lambda delay, callback: callbacks.append(callback))
        app.busy = False
        app.history = [{'role':'assistant','content':'Old answer'}]
        voice = self.module.AlwaysListeningVoice(app, self.tmp.name)
        spoken = []
        voice._speak = spoken.append
        voice._wait_and_speak()
        callbacks.pop()()
        self.assertEqual(spoken, [])

    def test_voice_can_speak_a_new_answer_from_the_expected_request(self):
        app = self.app()
        callbacks = []
        app.root = SimpleNamespace(after=lambda delay, callback: callbacks.append(callback))
        app.busy = False
        app.history = [{'role':'assistant','content':'Old answer'}]
        voice = self.module.AlwaysListeningVoice(app, self.tmp.name)
        spoken, done = [], threading.Event()
        def speak(text): spoken.append(text); done.set()
        voice._speak = speak
        voice._wait_and_speak()
        app.history.append({'role':'assistant','content':'Current answer'})
        callbacks.pop()()
        self.assertTrue(done.wait(2))
        self.assertEqual(spoken, ['Current answer'])

    def test_interrupt_uses_a_control_message_without_waiting_for_the_process(self):
        app = self.app()
        process = SimpleNamespace(stdin=StringIO(), poll=lambda: None)
        app._duplex_tts_process = process
        app._duplex_tts_pending_count = 4
        app._duplex_tts_active = True
        with patch.object(self.module, '_edie31210_send_mic_control'):
            self.module._edie31210_interrupt_tts(app)
        self.assertEqual(json.loads(process.stdin.getvalue())['type'], 'cancel')
        self.assertEqual(app._duplex_tts_pending_count, 0)

    def test_old_speech_completion_cannot_change_a_new_generation(self):
        app = self.app()
        app._duplex_tts_process = object()
        app._edie47_speech_generation = 2
        app._duplex_tts_pending_count = 3
        self.module._edie31210_tts_event(app, app._duplex_tts_process, {'type':'finished','generation':1})
        self.assertEqual(app._duplex_tts_pending_count, 3)

    def test_cancel_acknowledgement_cannot_clear_new_speech_already_queued(self):
        app = self.app()
        app._duplex_tts_process = object()
        app._edie47_speech_generation = 2
        app._duplex_tts_pending_count = 3
        self.module._edie31210_tts_event(app, app._duplex_tts_process, {'type':'cancelled','generation':2})
        self.assertEqual(app._duplex_tts_pending_count, 3)

    def test_safe_mode_and_capture_pause_override_saved_wake_permission(self):
        app = self.app()
        with patch.object(self.module, '_EDIE31270_PREVIOUS_PERMISSION', lambda _app, key: True):
            with patch.object(self.module, '_edie31260_safe_mode_enabled', lambda: True):
                self.assertFalse(self.module.EDIEApp._permission_enabled(app, 'wake_phrase_listening'))
            app._edie47_capture_paused = True
            with patch.object(self.module, '_edie31260_safe_mode_enabled', lambda: False):
                self.assertFalse(self.module.EDIEApp._permission_enabled(app, 'wake_phrase_listening'))
                self.assertTrue(self.module.EDIEApp._permission_enabled(app, 'web_search'))
