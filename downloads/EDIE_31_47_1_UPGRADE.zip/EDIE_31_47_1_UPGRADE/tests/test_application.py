import contextlib
import importlib.util
from io import StringIO
import json
import os
from pathlib import Path
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch
from edie.metadata import SOURCE_FILENAME


class ApplicationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.module_data = tempfile.TemporaryDirectory()
        source = Path(__file__).resolve().parents[1] / SOURCE_FILENAME
        with patch.dict(os.environ, {'EDIE_DATA_DIR': cls.module_data.name}):
            spec = importlib.util.spec_from_file_location('edie_upgrade_test_application', source)
            cls.module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(cls.module)

    @classmethod
    def tearDownClass(cls):
        cls.module_data.cleanup()

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    def app(self):
        app = SimpleNamespace(active_profile='Default', _closing=False, _lockdown_active=False)
        app.store = self.module.EDIEStore(Path(self.tmp.name) / 'test.sqlite3')
        class Coordinator:
            def learned_summary(self): return {}
            def _step(self, kind, objective):
                return {'checks': [{'status':'error','error':'Simulated failed check'}]}
        app._edie42_coordinator = Coordinator()
        return app

    def test_improvement_findings_point_to_code_and_specific_changes(self):
        source = Path(self.tmp.name) / 'layout_example.py'
        source.write_text(
            'class Window:\n'
            '    def layout(self, style, ready):\n'
            '        style.theme_use("clam")\n'
            '        style.configure("TFrame", background="white")\n'
            '        style.configure("TLabel", foreground="black")\n'
            '        style.map("TButton", foreground=[])\n'
            + '        if ready:\n            ready = False\n' * 80
            + '\ndef left_label(text):\n    return text.strip()\n'
            '\ndef right_label(text, optional=False):\n    return text.strip()\n',
            encoding='utf-8',
        )
        advisor = self.module.ProactiveImprovementAdvisor(SimpleNamespace(), source, self.tmp.name)
        report = advisor.analyse()
        layout = next(item for item in report['items'] if item['title'].endswith('layout'))
        self.assertIn('theme and widget style setup', layout['problem'])
        self.assertIn('lines 3 to 6 into a small helper', layout['recommendation'])
        self.assertIn('layout_example.py\nWindow.layout (lines 2 to ', layout['location'])
        self.assertIn('3          style.theme_use("clam")', layout['excerpt'])
        duplicate = next(item for item in report['items'] if item['title'].startswith('Duplicated code'))
        self.assertIn('left_label', duplicate['location'])
        self.assertIn('right_label', duplicate['location'])
        self.assertIn('If they serve the same purpose', duplicate['recommendation'])
        self.assertIn('return text.strip()', duplicate['excerpt'])
        self.assertEqual(advisor.analyse(), report)

    def test_advisor_regenerates_legacy_cache_for_unchanged_source(self):
        source = Path(self.tmp.name) / 'sample.py'
        text = 'def long_routine(ready):\n' + '    if ready:\n        ready = False\n' * 80
        source.write_text(text, encoding='utf-8')
        advisor = self.module.ProactiveImprovementAdvisor(SimpleNamespace(), source, self.tmp.name)
        digest = advisor._hash(text)
        advisor.last_hash = digest
        advisor.path.write_text(json.dumps({
            'status': 'complete',
            'source_hash': digest,
            '_edie46_source_path': str(source.resolve()),
            '_edie46_source_mtime_ns': source.stat().st_mtime_ns,
            '_edie46_source_size': source.stat().st_size,
            'items': [],
        }), encoding='utf-8')

        report = advisor.analyse()
        self.assertEqual(report['source_hash'], digest)
        self.assertEqual(report['report_version'], advisor.REPORT_VERSION)
        self.assertIn('Start with the code on lines 2 to 3', report['items'][0]['recommendation'])
        self.assertIn('if ready:', report['items'][0]['excerpt'])

    def test_resolved_finding_expires_after_24_hours_and_stays_hidden(self):
        data = Path(self.tmp.name)
        source = data / 'layout.py'
        definition = 'def layout(style, mark, ready):\n'
        styles = ('    style.theme_use("clam")\n'
                  '    style.configure("TFrame", background="white")\n'
                  '    style.configure("TLabel", foreground="black")\n'
                  '    style.configure("TButton", padding=4)\n'
                  '    style.map("TButton", foreground=[])\n')
        logo = ''.join(f'    mark.create_oval({index}, 1, 2, 3)\n' for index in range(4))
        branches = '    if ready:\n        ready = False\n' * 80
        original = definition + styles + logo + branches
        source.write_text(original, encoding='utf-8')
        advisor_type = self.module.ProactiveImprovementAdvisor
        advisor = advisor_type(SimpleNamespace(), source, data)

        with patch.object(self.module.time, 'time', return_value=1_700_000_000) as clock:
            original_id = advisor.analyse()['items'][0]['id']
            source.write_text('# Unrelated line above layout\n' + original, encoding='utf-8')
            shifted = advisor.analyse()
            self.assertEqual(shifted['items'][0]['id'], original_id)
            self.assertEqual(shifted['resolved'], [])

            source.write_text(definition + logo + branches, encoding='utf-8')
            resolved_at = 1_700_000_300
            clock.return_value = resolved_at
            fixed = advisor.analyse()
            self.assertNotEqual(fixed['items'][0]['id'], original_id)
            self.assertEqual([(item['id'], item['status'], item['resolved_at']) for item in fixed['resolved']],
                             [(original_id, 'Resolved', resolved_at)])

            # A portable upgrade can move the source to a different folder.
            upgrade = data / 'upgrade' / source.name
            upgrade.parent.mkdir()
            upgrade.write_bytes(source.read_bytes())
            restarted = advisor_type(SimpleNamespace(), upgrade, data)
            clock.return_value = resolved_at + 24 * 60 * 60 - 1
            self.assertEqual(restarted.analyse()['resolved'][0]['resolved_at'], resolved_at)
            clock.return_value += 1
            self.assertEqual(restarted.analyse()['resolved'], [])
            self.assertEqual(restarted._load()['status'], 'complete')

            history = json.loads(restarted.history_path.read_text(encoding='utf-8'))
            self.assertEqual(history[source.name]['resolved'][original_id], {'at': resolved_at})
            upgrade.write_text(original, encoding='utf-8')
            restored = restarted.analyse()
            self.assertNotIn(original_id, {item['id'] for item in restored['items']})
            self.assertEqual(restored['resolved'], [])

    def test_larger_focus_cannot_resolve_code_that_is_still_present(self):
        source = Path(self.tmp.name) / 'example.py'
        definition = 'def layout(mark, panel, ready):\n'
        logo = ''.join(f'    mark.create_oval({index}, 1, 2, 3)\n' for index in range(4))
        panel = ''.join(f'    panel.configure(padding={index})\n' for index in range(6))
        branches = '    if ready:\n        ready = False\n' * 80
        source.write_text(definition + logo + branches, encoding='utf-8')
        advisor = self.module.ProactiveImprovementAdvisor(SimpleNamespace(), source, self.tmp.name)
        first = advisor.analyse()['items'][0]['id']

        source.write_text(definition + panel + '    mark.pack()\n' + logo + branches, encoding='utf-8')
        reranked = advisor.analyse()
        self.assertNotEqual(reranked['items'][0]['id'], first)
        self.assertIn(first, reranked['finding_ids'])
        self.assertEqual(reranked['resolved'], [])

        source.write_text(definition + panel + branches, encoding='utf-8')
        self.assertEqual([item['id'] for item in advisor.analyse()['resolved']], [first])

    def test_failed_source_scan_does_not_resolve_a_duplicate(self):
        source = Path(self.tmp.name) / 'duplicate.py'
        code = 'def first():\n    return 1\n\ndef second():\n    return 1\n'
        source.write_text(code, encoding='utf-8')
        advisor = self.module.ProactiveImprovementAdvisor(SimpleNamespace(), source, self.tmp.name)
        original_id = advisor.analyse()['items'][0]['id']

        source.write_text('def unfinished(', encoding='utf-8')
        failed = advisor.analyse()
        self.assertEqual(failed['status'], 'error')
        self.assertEqual(failed['resolved'], [])
        source.write_text(code, encoding='utf-8')
        self.assertEqual(advisor.analyse()['items'][0]['id'], original_id)

        source.write_text('def first():\n    return 1\n', encoding='utf-8')
        fixed = advisor.analyse()
        self.assertEqual(fixed['items'], [])
        self.assertEqual([item['id'] for item in fixed['resolved']], [original_id])

    def test_approval_rejects_changes_to_either_tested_source(self):
        module = self.module
        root = Path(self.tmp.name)
        installed = root / 'installed.py'
        candidate = root / 'candidate.py'
        current = 'label = "current"\n'
        proposed = 'label = "proposed"\n'
        digest = module.EvolutionEngine.sha256
        manifest = {'candidate_sha256': digest(proposed), 'base_sha256': digest(current)}
        validate = Mock()
        app = SimpleNamespace(_evolution_engine=SimpleNamespace(validate_candidate=validate))

        with patch.object(module, 'APP', installed), patch.object(module.messagebox, 'askyesno') as ask:
            for current_source, proposed_source, expected in (
                (current, proposed + '# different candidate\n', 'The proposal changed after testing'),
                (current + '# different base\n', proposed, "EDIE's installed source changed"),
            ):
                with self.subTest(expected=expected):
                    installed.write_text(current_source, encoding='utf-8')
                    candidate.write_text(proposed_source, encoding='utf-8')
                    with self.assertRaisesRegex(ValueError, expected):
                        module.EDIEApp._evolution_confirm_approval(app, None, candidate, manifest, digest(current))
            validate.assert_not_called()
            ask.assert_not_called()

    def test_approval_checks_validation_and_returns_only_confirmed_hashes(self):
        module = self.module
        root = Path(self.tmp.name)
        installed = root / 'installed.py'
        candidate = root / 'candidate.py'
        current = 'label = "current"\n'
        proposed = 'label = "proposed"\n'
        installed.write_text(current, encoding='utf-8')
        candidate.write_text(proposed, encoding='utf-8')
        digest = module.EvolutionEngine.sha256
        manifest = {
            'candidate_sha256': digest(proposed),
            'base_sha256': digest(current),
            'allowed_symbols': ['EDIEApp.sample'],
            'validation': {'risks': [{'severity': 'REVIEW', 'message': 'Read the proposal diff'}]},
        }
        validate = Mock(return_value={'passed': False})
        app = SimpleNamespace(_evolution_engine=SimpleNamespace(validate_candidate=validate))
        parent = object()

        def request_approval():
            return module.EDIEApp._evolution_confirm_approval(app, parent, candidate, manifest, digest(current))

        with patch.object(module, 'APP', installed), patch.object(module.messagebox, 'askyesno') as ask:
            with self.assertRaisesRegex(ValueError, 'Final static validation failed'):
                request_approval()
            validate.assert_called_once_with(current, proposed, ['EDIEApp.sample'])
            ask.assert_not_called()
            validate.return_value = {'passed': True}
            ask.side_effect = [False, True, False, True, True]
            self.assertIsNone(request_approval())
            self.assertIsNone(request_approval())
            self.assertEqual(request_approval(), (digest(proposed), digest(current)))
            self.assertEqual([call.args[0] for call in ask.call_args_list], [
                'Sensitive code review required',
                'Sensitive code review required', "Approve EDIE's improvement?",
                'Sensitive code review required', "Approve EDIE's improvement?",
            ])
            self.assertTrue(all(call.kwargs['parent'] is parent for call in ask.call_args_list))

        self.assertEqual(installed.read_text(encoding='utf-8'), current)
        self.assertEqual(candidate.read_text(encoding='utf-8'), proposed)
        self.assertIn('_evolution_confirm_approval', module.EvolutionEngine.PROTECTED_METHODS)

    def test_malformed_performance_modes_do_not_block_startup(self):
        path = Path(self.tmp.name) / 'edie46_performance.json'
        for modes in ([], None, 7, {'Default': []}, {'Default': {'bad':'shape'}}):
            path.write_text(json.dumps({'modes': modes}))
            perf = self.module.EDIE46Performance(SimpleNamespace(active_profile='Default'), self.tmp.name)
            self.assertEqual(perf.mode(), 'Balanced')

    def test_health_failures_are_not_reported_as_completed(self):
        app = self.app()
        core = self.module.EDIE45Automation(app)
        job = core.prepare('Check EDIE local health', option='quick')
        result = core.run(job['id'])
        self.assertEqual(result['state'], 'partial')
        self.assertEqual(result['receipts'][0]['state'], 'partial')
        self.assertEqual(app._edie47_active_jobs, {})

    def test_profile_change_cancels_the_original_job_without_cross_profile_receipts(self):
        app = self.app()
        def step(kind, objective):
            app.active_profile = 'Other'
            return {'ok': True}
        app._edie42_coordinator._step = step
        core = self.module.EDIE45Automation(app)
        job = core.prepare('Check EDIE local health', option='quick')
        result = core.run(job['id'])
        self.assertEqual(result['state'], 'cancelled')
        self.assertEqual(result['receipts'], [])
        with app.store._db() as db:
            saved = db.execute('SELECT profile,state FROM e45_jobs WHERE id=?', (job['id'],)).fetchone()
            self.assertEqual(tuple(saved), ('Default', 'cancelled'))
            self.assertEqual(db.execute('SELECT count(*) FROM e45_receipts').fetchone()[0], 0)

    def test_voice_does_not_replay_an_old_answer(self):
        app = self.app()
        callbacks = []
        app.root = SimpleNamespace(after=lambda delay, callback: callbacks.append(callback))
        app.busy = False
        app.history = [{'role':'assistant','content':'Old answer'}]
        voice = self.module.AlwaysListeningVoice(app, self.tmp.name)
        spoken = []
        voice._speak = spoken.append
        voice._wait_and_speak()
        callbacks.pop()()
        self.assertEqual(spoken, [])

    def test_voice_can_speak_a_new_answer_from_the_expected_request(self):
        app = self.app()
        callbacks = []
        app.root = SimpleNamespace(after=lambda delay, callback: callbacks.append(callback))
        app.busy = False
        app.history = [{'role':'assistant','content':'Old answer'}]
        voice = self.module.AlwaysListeningVoice(app, self.tmp.name)
        spoken, done = [], threading.Event()
        def speak(text): spoken.append(text); done.set()
        voice._speak = speak
        voice._wait_and_speak()
        app.history.append({'role':'assistant','content':'Current answer'})
        callbacks.pop()()
        self.assertTrue(done.wait(2))
        self.assertEqual(spoken, ['Current answer'])

    def test_interrupt_uses_a_control_message_without_waiting_for_the_process(self):
        app = self.app()
        process = SimpleNamespace(stdin=StringIO(), poll=lambda: None)
        app._duplex_tts_process = process
        app._duplex_tts_pending_count = 4
        app._duplex_tts_active = True
        with patch.object(self.module, '_edie31210_send_mic_control'):
            self.module._edie31210_interrupt_tts(app)
        self.assertEqual(json.loads(process.stdin.getvalue())['type'], 'cancel')
        self.assertEqual(app._duplex_tts_pending_count, 0)

    def test_old_speech_completion_cannot_change_a_new_generation(self):
        app = self.app()
        app._duplex_tts_process = object()
        app._edie47_speech_generation = 2
        app._duplex_tts_pending_count = 3
        self.module._edie31210_tts_event(app, app._duplex_tts_process, {'type':'finished','generation':1})
        self.assertEqual(app._duplex_tts_pending_count, 3)

    def test_cancel_acknowledgement_cannot_clear_new_speech_already_queued(self):
        app = self.app()
        app._duplex_tts_process = object()
        app._edie47_speech_generation = 2
        app._duplex_tts_pending_count = 3
        self.module._edie31210_tts_event(app, app._duplex_tts_process, {'type':'cancelled','generation':2})
        self.assertEqual(app._duplex_tts_pending_count, 3)

    def test_safe_mode_and_capture_pause_override_saved_wake_permission(self):
        app = self.app()
        with patch.object(self.module, '_EDIE31270_PREVIOUS_PERMISSION', lambda _app, key: True):
            with patch.object(self.module, '_edie31260_safe_mode_enabled', lambda: True):
                self.assertFalse(self.module.EDIEApp._permission_enabled(app, 'wake_phrase_listening'))
            app._edie47_capture_paused = True
            with patch.object(self.module, '_edie31260_safe_mode_enabled', lambda: False):
                self.assertFalse(self.module.EDIEApp._permission_enabled(app, 'wake_phrase_listening'))
                self.assertTrue(self.module.EDIEApp._permission_enabled(app, 'web_search'))
