from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from edie.persistence import read_json, write_json, update_json
from edie.config import VoiceSettings, load_voice_settings, save_voice_settings


class PersistenceTests(unittest.TestCase):
    def test_concurrent_writes_are_complete_and_leave_no_temporary_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'nested' / 'settings.json'
            with ThreadPoolExecutor(max_workers=12) as pool:
                list(pool.map(lambda n: write_json(path, {'number': n, 'payload': 'x' * 10000}), range(60)))
            value = json.loads(path.read_text())
            self.assertEqual(value['payload'], 'x' * 10000)
            self.assertEqual(list(path.parent.glob('*.tmp')), [])

    def test_cross_process_updates_do_not_lose_increments(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'counter.json'
            write_json(path, {'count': 0})
            script = ('from edie.persistence import update_json; import sys; '
                      '[update_json(sys.argv[1], {}, lambda v: {"count":v.get("count",0)+1}) for _ in range(15)]')
            processes = [subprocess.Popen([sys.executable, '-c', script, str(path)]) for _ in range(4)]
            for process in processes:
                self.assertEqual(process.wait(timeout=20), 0)
            self.assertEqual(read_json(path, {})['count'], 60)

    def test_invalid_container_and_invalid_json_recover_without_mutable_defaults(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'settings.json'
            path.write_text('[]')
            self.assertEqual(read_json(path, {}), {})
            path.write_text('{broken')
            default = {'values': []}
            read_json(path, default)['values'].append('changed')
            self.assertEqual(default, {'values': []})

    def test_invalid_new_value_preserves_previous_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'settings.json'
            write_json(path, {'ok': True})
            with self.assertRaises(ValueError):
                write_json(path, {'invalid': float('nan')})
            self.assertEqual(read_json(path, {}), {'ok': True})

    def test_profile_voice_settings_are_validated_and_isolated(self):
        with tempfile.TemporaryDirectory() as tmp:
            save_voice_settings(tmp, 'A', {'rate': 210, 'volume': .4, 'language': 'fr'})
            self.assertEqual(load_voice_settings(tmp, 'A').rate, 210)
            self.assertEqual(load_voice_settings(tmp, 'B'), VoiceSettings())
            malformed = VoiceSettings.from_mapping({'rate': 'bad', 'volume': float('nan'), 'language': ['en']})
            self.assertEqual(malformed, VoiceSettings())
