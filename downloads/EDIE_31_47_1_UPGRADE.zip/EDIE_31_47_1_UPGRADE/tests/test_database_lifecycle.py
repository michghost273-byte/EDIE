"""Keep strong references to reveal leaks without relying on garbage collection.

This models the Windows file-locking failure even when tests run on POSIX.
"""
import importlib.util
import os
from pathlib import Path
import sqlite3
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from edie.metadata import SOURCE_FILENAME


class DatabaseLifecycleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.module_data = tempfile.TemporaryDirectory()
        source = Path(__file__).resolve().parents[1] / SOURCE_FILENAME
        with patch.dict(os.environ, {'EDIE_DATA_DIR': cls.module_data.name}):
            spec = importlib.util.spec_from_file_location('edie_database_lifecycle', source)
            cls.app = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(cls.app)

    @classmethod
    def tearDownClass(cls):
        cls.module_data.cleanup()

    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.connections = []
        self.addCleanup(self.close_remaining)
        original_connect = sqlite3.connect
        connections = self.connections
        class TrackedConnection(sqlite3.Connection):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.closed_explicitly = False
                connections.append(self)
            def close(self):
                result = super().close()
                self.closed_explicitly = True
                return result
        self.connection_type = TrackedConnection
        def connect(*args, **kwargs):
            kwargs.setdefault('factory', TrackedConnection)
            return original_connect(*args, **kwargs)
        patcher = patch.object(sqlite3, 'connect', side_effect=connect)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.path = Path(self.directory.name) / 'test.sqlite3'

    def close_remaining(self):
        for connection in self.connections:
            connection.close()

    def assert_all_closed(self):
        self.assertTrue(self.connections, 'The probe must open real SQLite connections')
        for index, connection in enumerate(self.connections):
            self.assertTrue(connection.closed_explicitly, f'Connection {index} was not explicitly closed')
            with self.assertRaises(sqlite3.ProgrammingError):
                connection.execute('SELECT 1')

    def test_store_initialisation_closes_connections_before_temp_cleanup(self):
        store = self.app.EDIEStore(self.path)
        self.assert_all_closed()
        store.add_memory('Profile', 'Database cleanup regression')
        self.assert_all_closed()

    def test_failed_schema_initialisation_closes_its_connection(self):
        with patch.object(self.app, '_edie47_ensure_schema', side_effect=RuntimeError('simulated migration failure')):
            with self.assertRaisesRegex(RuntimeError, 'simulated migration failure'):
                self.app.EDIEStore(self.path)
        self.assert_all_closed()

    def test_transaction_failure_rolls_back_and_closes(self):
        store = self.app.EDIEStore(self.path)
        with self.assertRaisesRegex(RuntimeError, 'rollback probe'):
            with store._db() as connection:
                connection.execute("INSERT INTO migrations VALUES('uncommitted-probe','now')")
                raise RuntimeError('rollback probe')
        self.assertFalse(store.migration_done('uncommitted-probe'))
        self.assert_all_closed()

    def test_connection_setup_failure_closes_its_connection(self):
        store = self.app.EDIEStore(self.path)
        with patch.object(self.connection_type, 'execute', side_effect=sqlite3.OperationalError('simulated pragma failure')):
            with self.assertRaisesRegex(sqlite3.OperationalError, 'simulated pragma failure'):
                store._connect()
        self.assert_all_closed()

    def test_capability_self_test_closes_its_fixture_connections(self):
        self.app.EDIECapabilityRuntime.self_test()
        self.assert_all_closed()

    def test_backup_closes_source_if_opening_snapshot_fails(self):
        store = self.app.EDIEStore(self.path)
        app = SimpleNamespace(store=store, active_profile='Profile')
        tracked_connect = sqlite3.connect
        def fail_snapshot(database, *args, **kwargs):
            if Path(database).name == 'profile_database.sqlite3':
                raise sqlite3.OperationalError('simulated snapshot open failure')
            return tracked_connect(database, *args, **kwargs)
        with patch.object(sqlite3, 'connect', side_effect=fail_snapshot):
            with self.assertRaisesRegex(sqlite3.OperationalError, 'simulated snapshot open failure'):
                self.app._e20_profile_backup(app, 'Profile')
        self.assert_all_closed()
