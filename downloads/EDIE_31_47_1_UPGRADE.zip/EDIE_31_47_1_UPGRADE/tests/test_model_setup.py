from pathlib import Path
import tempfile
import unittest
import zipfile

from edie.model_setup import safe_extract


class ModelSetupTests(unittest.TestCase):
    def test_model_path_traversal_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            archive = Path(tmp) / 'bad.zip'
            with zipfile.ZipFile(archive, 'w') as handle:
                handle.writestr('../outside.txt', 'invalid')
            with self.assertRaises(ValueError):
                safe_extract(archive, Path(tmp) / 'extracted')
            self.assertFalse((Path(tmp) / 'outside.txt').exists())
