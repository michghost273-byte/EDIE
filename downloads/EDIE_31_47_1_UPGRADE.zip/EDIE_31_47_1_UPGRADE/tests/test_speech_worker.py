import json
import os
from pathlib import Path
import queue
import subprocess
import sys
import tempfile
import textwrap
import threading
import time
import unittest


class SpeechWorkerTests(unittest.TestCase):
    def test_speech_can_be_cancelled_before_utterance_finishes_and_eof_exits(self):
        with tempfile.TemporaryDirectory() as tmp:
            Path(tmp, 'pyttsx3.py').write_text(textwrap.dedent('''
                class Engine:
                    def __init__(self): self.active=None
                    def connect(self, event, callback): self.callback=callback
                    def startLoop(self, external): pass
                    def endLoop(self): pass
                    def setProperty(self, name, value): pass
                    def say(self, text, name): self.active=name
                    def iterate(self): pass
                    def stop(self): self.active=None
                def init(**kwargs): return Engine()
            '''))
            root = Path(__file__).resolve().parents[1]
            env = os.environ.copy()
            env['PYTHONPATH'] = tmp + os.pathsep + str(root)
            env['EDIE_APP_DIR'] = str(root)
            env.pop('EDIE_PARENT_PID', None)
            process = subprocess.Popen([sys.executable, str(root / 'EDIE_TTS_STREAM_WORKER_31_21_0.py')],
                                       stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                       text=True, env=env)
            events = queue.Queue()
            def read():
                for line in process.stdout:
                    events.put(json.loads(line))
            reader = threading.Thread(target=read, daemon=True)
            reader.start()
            try:
                self.assertEqual(events.get(timeout=5)['type'], 'ready')
                process.stdin.write(json.dumps({'type':'speak','text':'Long speech that does not finish.', 'id':'current', 'generation':1}) + '\n')
                process.stdin.flush()
                self.assertEqual(events.get(timeout=3)['type'], 'started')
                started = time.monotonic()
                process.stdin.write('{"type":"cancel","generation":2}\n')
                process.stdin.flush()
                self.assertEqual(events.get(timeout=3)['type'], 'cancelled')
                self.assertLess(time.monotonic() - started, .75)
                process.stdin.close()
                self.assertEqual(process.wait(timeout=5), 0)
            finally:
                if process.poll() is None:
                    process.kill()
                    process.wait()
                process.stdout.close()
                process.stderr.close()
                reader.join(timeout=1)
