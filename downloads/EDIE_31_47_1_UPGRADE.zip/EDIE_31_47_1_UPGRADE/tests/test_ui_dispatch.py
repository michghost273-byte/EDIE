import threading
import unittest

from edie.runtime import UIDispatcher


class Root:
    def __init__(self):
        self.owner = threading.get_ident()
        self.callbacks = {}
        self.next = 0
    def after(self, delay, callback=None, *args):
        assert threading.get_ident() == self.owner, 'Tcl called off its owning thread'
        self.next += 1
        self.callbacks[self.next] = (callback, args)
        return self.next
    def after_cancel(self, identifier):
        assert threading.get_ident() == self.owner
        self.callbacks.pop(identifier, None)


class DispatcherTests(unittest.TestCase):
    def test_worker_scheduling_and_cancellation_never_call_tcl_off_thread(self):
        root = Root()
        dispatcher = UIDispatcher(root).install()
        observed = []
        def worker():
            root.after(0, lambda: observed.append('kept'))
            cancelled = root.after(0, lambda: observed.append('cancelled'))
            root.after_cancel(cancelled)
        thread = threading.Thread(target=worker)
        thread.start()
        thread.join(timeout=2)
        dispatcher._pump()
        for callback, args in list(root.callbacks.values()):
            if callback and getattr(callback, '__name__', '') == 'run':
                callback(*args)
        self.assertEqual(observed, ['kept'])
        dispatcher.close()
        with self.assertRaises(RuntimeError):
            root.after(0, lambda: None)
