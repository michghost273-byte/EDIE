import unittest
from edie.outcomes import result_state


class OutcomeTests(unittest.TestCase):
    def test_unhealthy_nested_checks_never_look_successful(self):
        for status in ('error', 'missing', 'degraded', 'not_configured', 'not_running'):
            self.assertEqual(result_state({'checks':[{'status':status}]}), 'partial')
        self.assertEqual(result_state({'checks':[{'status':'ok'},{'passed':True}]}), 'completed')
        self.assertEqual(result_state({'blocked':'Permission disabled'}), 'blocked')
        self.assertEqual(result_state({'reachable':False}), 'unavailable')
