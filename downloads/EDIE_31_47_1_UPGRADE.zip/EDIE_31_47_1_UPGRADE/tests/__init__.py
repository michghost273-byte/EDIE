"""Headless regression tests; no microphone, screen capture or live AI required."""
