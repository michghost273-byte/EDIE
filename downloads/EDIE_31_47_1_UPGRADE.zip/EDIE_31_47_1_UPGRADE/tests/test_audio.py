from io import StringIO
import threading
import time
import unittest

from edie.audio import CapturePump, SpeechSegmenter, read_commands
from edie.config import VoiceSettings
from edie.speech import SpeechStream, speech_chunks


class AudioTests(unittest.TestCase):
    def test_bounded_capture_retains_the_most_recent_audio(self):
        pump = CapturePump(None, threading.Event(), capacity=3)
        for index in range(20):
            pump.offer((index, 'frame'))
        self.assertEqual(pump.frames.qsize(), 3)
        self.assertEqual(pump.dropped, 17)
        self.assertEqual([pump.frames.get()[0] for _ in range(3)], [17, 18, 19])

    def test_preroll_and_configurable_silence(self):
        segmenter = SpeechSegmenter(VoiceSettings(silence_seconds=.5))
        segmenter.feed('quiet-1', .001)
        segmenter.feed('quiet-2', .001)
        segmenter.feed('speech', .1)
        self.assertTrue(segmenter.started)
        self.assertIsNone(segmenter.feed('pause-1', .001))
        result = segmenter.feed('pause-2', .001)
        self.assertEqual(result, ['quiet-1', 'quiet-2', 'speech', 'pause-1', 'pause-2'])

    def test_preroll_can_be_disabled(self):
        segmenter = SpeechSegmenter(VoiceSettings(pre_roll_seconds=0, silence_seconds=.5))
        segmenter.feed('old', .001)
        segmenter.feed('speech', .1)
        segmenter.feed('pause-1', .001)
        self.assertEqual(segmenter.feed('pause-2', .001), ['speech', 'pause-1', 'pause-2'])

    def test_eof_and_invalid_commands_stop_capture(self):
        stop = threading.Event()
        read_commands(StringIO('[]\nnull\n{"type":"tts_state","active":true}\n'), stop)
        self.assertTrue(stop.is_set())

    def test_long_text_is_preserved_and_bounded(self):
        text = ('A sentence with important details. ' * 130).strip()
        chunks = list(speech_chunks(text))
        self.assertEqual(' '.join(chunks), text)
        self.assertTrue(all(0 < len(chunk) <= 500 for chunk in chunks))

    def test_code_fences_split_across_model_tokens_are_not_spoken(self):
        stream = SpeechStream()
        result = []
        for token in ['Hello, this is EDIE. ', '`', '`', '`python\nsecret_code()', '`', '`', '`', '\nThis is the final explanation.']:
            result.extend(stream.feed(token))
        result.extend(stream.finish())
        spoken = ' '.join(result)
        self.assertIn('Hello', spoken)
        self.assertIn('final explanation', spoken)
        self.assertNotIn('secret_code', spoken)
        self.assertNotIn('python', spoken)
