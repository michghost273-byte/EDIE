from pathlib import Path
import sqlite3
import tempfile
import unittest
import zipfile

from edie.backups import create_backup, verify_backup, stage_restore
from edie.persistence import write_json


class BackupTests(unittest.TestCase):
    def test_backup_includes_new_settings_and_wal_data_and_can_be_staged(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / 'data'
            data.mkdir()
            write_json(data / 'voice47_settings.json', {'profiles': {'A': {'rate': 200}}})
            conn = sqlite3.connect(data / 'edie_core.sqlite3')
            try:
                conn.execute('PRAGMA journal_mode=WAL')
                conn.execute('CREATE TABLE important (value TEXT)')
                conn.execute('INSERT INTO important VALUES (?)', ('committed WAL value',))
                conn.commit()
                backup, manifest = create_backup(data)
                self.assertEqual(manifest['status'], 'complete')
                self.assertTrue(verify_backup(backup)['verified'])
                staged = stage_restore(backup, Path(tmp) / 'recovered')
                self.assertTrue((staged / 'voice47_settings.json').is_file())
                recovered = sqlite3.connect(staged / 'edie_core.sqlite3')
                try:
                    self.assertEqual(recovered.execute('SELECT value FROM important').fetchone()[0], 'committed WAL value')
                finally:
                    recovered.close()
                with self.assertRaises(FileExistsError):
                    stage_restore(backup, staged)
            finally:
                conn.close()

    def test_credential_exclusions_are_reported_as_partial(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp)
            write_json(data / 'credentials.json', {'sensitive': 'not-in-backup'})
            backup, manifest = create_backup(data)
            self.assertEqual(manifest['status'], 'partial')
            self.assertEqual(manifest['skipped'][0]['path'], 'credentials.json')
            with zipfile.ZipFile(backup) as archive:
                self.assertNotIn('credentials.json', archive.namelist())

    def test_extra_unverified_members_and_traversal_are_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp)
            write_json(data / 'settings.json', {'ok': True})
            backup, _ = create_backup(data)
            with zipfile.ZipFile(backup, 'a') as archive:
                archive.writestr('unexpected.json', '{}')
            with self.assertRaises(ValueError):
                verify_backup(backup)
            malicious = data / 'malicious.zip'
            with zipfile.ZipFile(malicious, 'w') as archive:
                archive.writestr('../outside.json', '{}')
            with self.assertRaises(ValueError):
                verify_backup(malicious)
