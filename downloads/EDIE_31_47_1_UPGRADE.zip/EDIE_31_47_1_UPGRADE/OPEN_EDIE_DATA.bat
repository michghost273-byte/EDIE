@echo off
call "%~dp0START_EDIE.bat" --open-data
