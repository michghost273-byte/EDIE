"""Manifest-verified full-data backups with SQLite online snapshots and staged recovery."""
from __future__ import annotations

from datetime import datetime, timezone
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import secrets
import shutil
import sqlite3
import tempfile
import zipfile

from .metadata import VERSION

MAX_FILE = 256 * 1024 * 1024
MAX_TOTAL = 1024 * 1024 * 1024
MAX_ENTRIES = 20000
EXCLUDED_DIRS = {'backups', 'security_backups', 'recovery_staging', 'runtime', 'runtimes',
                 'whisper_cache', 'voice_models', 'workers', '__pycache__', '.venv', '.git'}


def _member(name):
    path = PurePosixPath(name)
    if (not name or '\\' in name or ':' in name or path.is_absolute()
            or '..' in path.parts or any(part in {'', '.'} for part in name.split('/'))):
        raise ValueError('Unsafe archive member')
    return path


def create_backup(data_dir, reason='manual'):
    data = Path(data_dir).resolve()
    destination = data / 'backups' / 'reliability'
    destination.mkdir(parents=True, exist_ok=True)
    target = destination / ('EDIE_' + datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_') + secrets.token_hex(4) + '.zip')
    temporary = target.with_suffix('.partial')
    entries, skipped, total = [], [], 0
    try:
        with zipfile.ZipFile(temporary, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for folder, directories, filenames in os.walk(data, followlinks=False):
                directories[:] = sorted(d for d in directories if d not in EXCLUDED_DIRS and not (Path(folder) / d).is_symlink())
                for filename in sorted(filenames):
                    source = Path(folder) / filename
                    relative = source.relative_to(data).as_posix()
                    if source.suffix not in {'.json', '.jsonl', '.sqlite3'} or filename.startswith('edie_ui_responsiveness'):
                        continue
                    if any(word in filename.casefold() for word in ('credential', 'password', 'secret', 'token')):
                        skipped.append({'path': relative, 'reason': 'Credential-like file is excluded; use OS credential backup separately.'})
                        continue
                    try:
                        if source.is_symlink() or data not in source.resolve().parents:
                            raise ValueError('Symbolic link or path outside EDIE data')
                        size = source.stat().st_size
                        if size > MAX_FILE or total + size > MAX_TOTAL or len(entries) >= MAX_ENTRIES:
                            raise ValueError('Backup size/entry limit exceeded')
                        if source.suffix == '.sqlite3':
                            with tempfile.TemporaryDirectory(prefix='edie-snapshot-') as tmp:
                                snapshot = Path(tmp) / 'snapshot.sqlite3'
                                with closing(sqlite3.connect(source, timeout=5)) as src, closing(sqlite3.connect(snapshot)) as dst:
                                    src.backup(dst)
                                    if dst.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
                                        raise ValueError('Database integrity check failed')
                                payload = snapshot.read_bytes()
                        else:
                            payload = source.read_bytes()
                        if len(payload) > MAX_FILE or total + len(payload) > MAX_TOTAL:
                            raise ValueError('Backup size limit exceeded')
                        archive.writestr(relative, payload)
                        entries.append({'path': relative, 'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()})
                        total += len(payload)
                    except (OSError, sqlite3.Error, ValueError) as exc:
                        skipped.append({'path': relative, 'reason': type(exc).__name__ + ': ' + str(exc)[:180]})
            manifest = {'format': 'EDIE_FULL_BACKUP_V2', 'release': VERSION,
                        'created_at': datetime.now(timezone.utc).isoformat(), 'reason': str(reason)[:80],
                        'scope': 'All EDIE profiles; excludes downloaded models, runtimes and OS credentials.',
                        'contains_personal_data': True, 'entries': entries, 'skipped': skipped,
                        'status': 'partial' if skipped else 'complete'}
            archive.writestr('MANIFEST.json', json.dumps(manifest, indent=2, ensure_ascii=False))
        os.replace(temporary, target)
        if os.name != 'nt':
            target.chmod(0o600)
        verify_backup(target)
        return target, manifest
    finally:
        temporary.unlink(missing_ok=True)


def verify_backup(path):
    with zipfile.ZipFile(path) as archive:
        members = archive.infolist()
        names = [info.filename for info in members]
        if len(members) > MAX_ENTRIES + 1 or len(names) != len(set(names)):
            raise ValueError('Too many or duplicate archive entries')
        total = 0
        for info in members:
            _member(info.filename)
            if (info.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError('Symbolic links are not accepted')
            if info.file_size > MAX_FILE:
                raise ValueError('Archive member exceeds recovery limit')
            total += info.file_size
        if total > MAX_TOTAL or archive.getinfo('MANIFEST.json').file_size > 2 * 1024 * 1024:
            raise ValueError('Archive exceeds recovery limits')
        manifest = json.loads(archive.read('MANIFEST.json'))
        if not isinstance(manifest, dict) or manifest.get('format') != 'EDIE_FULL_BACKUP_V2' or not isinstance(manifest.get('entries'), list):
            raise ValueError('Unsupported backup manifest')
        listed = set()
        for item in manifest['entries']:
            if not isinstance(item, dict) or not isinstance(item.get('path'), str):
                raise ValueError('Invalid manifest entry')
            name = item['path']
            _member(name)
            if name in listed or name == 'MANIFEST.json':
                raise ValueError('Duplicate or invalid manifest member')
            listed.add(name)
            payload = archive.read(name)
            if len(payload) != item.get('bytes') or hashlib.sha256(payload).hexdigest() != item.get('sha256'):
                raise ValueError('Backup checksum mismatch: ' + name)
            if name.endswith('.sqlite3'):
                with tempfile.TemporaryDirectory(prefix='edie-verify-') as tmp:
                    database = Path(tmp) / 'verify.sqlite3'
                    database.write_bytes(payload)
                    with closing(sqlite3.connect(database)) as conn:
                        if conn.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
                            raise ValueError('Database integrity check failed')
        if listed | {'MANIFEST.json'} != set(names):
            raise ValueError('Archive contains files not covered by its manifest')
    return {'verified': True, 'files': len(listed), 'bytes': total, 'manifest': manifest,
            'verification': 'Checksums and SQLite integrity; use staged recovery to rehearse restoration.'}


def stage_restore(path, destination):
    report = verify_backup(path)
    target = Path(destination).resolve()
    target.mkdir(parents=True, exist_ok=False)
    try:
        with zipfile.ZipFile(path) as archive:
            for item in report['manifest']['entries']:
                member = _member(item['path'])
                output = target.joinpath(*member.parts)
                output.parent.mkdir(parents=True, exist_ok=True)
                with output.open('xb') as handle:
                    handle.write(archive.read(item['path']))
        return target
    except Exception:
        shutil.rmtree(target)
        raise
