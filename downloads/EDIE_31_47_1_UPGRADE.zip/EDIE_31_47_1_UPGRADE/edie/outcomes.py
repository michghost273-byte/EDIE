"""Shared interpretation of tool results, including nested health checks."""
from __future__ import annotations


def result_state(payload):
    if not isinstance(payload, dict):
        return 'completed'
    if payload.get('blocked'):
        return 'blocked'
    if payload.get('unavailable') or payload.get('available') is False or payload.get('reachable') is False:
        return 'unavailable'
    if payload.get('error') or payload.get('ok') is False or payload.get('passed') is False:
        return 'partial'
    if str(payload.get('status', '')).casefold() in {'failed', 'error', 'degraded', 'warning'}:
        return 'partial'
    checks = payload.get('checks', [])
    if isinstance(checks, dict):
        checks = list(checks.values())
    if isinstance(checks, list):
        for check in checks:
            if not isinstance(check, dict):
                continue
            status = str(check.get('status', 'ok')).casefold()
            if check.get('error') or check.get('ok') is False or check.get('passed') is False or status not in {
                    'none', 'ok', 'ready', 'pass', 'passed', 'healthy', 'success', 'available', 'completed', 'not_applicable'}:
                return 'partial'
    return 'completed'
