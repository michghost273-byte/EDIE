"""Read and update Knowledge Vault snapshots of user-selected files."""

import math
from pathlib import Path
import stat

from .persistence import read_json, update_json


MAX_SOURCE_BYTES = 500_000
MAX_INDEX_CHARACTERS = 180_000


def source_path(record):
    path = record.get("path")
    return path if isinstance(path, str) else ""


def load_records(index_path):
    return [record for record in read_json(index_path, []) if isinstance(record, dict)]


def check_source(record):
    """Compare source metadata with the indexed copy, including older entries."""
    filename = source_path(record)
    if not filename:
        return "Unavailable"
    try:
        current = Path(filename).stat()
    except (FileNotFoundError, NotADirectoryError):
        return "Missing"
    except (OSError, ValueError):
        return "Unavailable"
    if not stat.S_ISREG(current.st_mode):
        return "Unavailable"

    size = record.get("size")
    if type(size) is int and current.st_size != size:
        return "Changed"
    modified_ns = record.get("modified_ns")
    if type(modified_ns) is int:
        return "Up to date" if current.st_mtime_ns == modified_ns else "Changed"
    modified = record.get("modified")
    if type(modified) is int or (type(modified) is float and math.isfinite(modified)):
        return "Up to date" if current.st_mtime == modified else "Changed"
    return "Needs refresh"


def read_source(filename):
    """Read a bounded snapshot and verify that its recorded metadata matches."""
    source = Path(filename)
    before = source.stat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError("The original is no longer a file.")
    if before.st_size > MAX_SOURCE_BYTES:
        raise ValueError("The file is larger than 500 KB.")
    with source.open("rb") as handle:
        raw = handle.read(MAX_SOURCE_BYTES + 1)
    after = source.stat()
    if len(raw) > MAX_SOURCE_BYTES:
        raise ValueError("The file is larger than 500 KB.")
    if (len(raw) != before.st_size
            or (before.st_mtime_ns, before.st_size, before.st_dev, before.st_ino)
            != (after.st_mtime_ns, after.st_size, after.st_dev, after.st_ino)):
        raise ValueError("The file changed while EDIE was reading it. Try refreshing again.")
    content = raw.decode("utf-8", errors="replace").replace("\r\n", "\n").replace("\r", "\n").replace("\x00", "")
    content = content[:MAX_INDEX_CHARACTERS]
    return {
        "name": source.name,
        "path": str(source),
        "content": content,
        "words": len(content.split()),
        "modified": after.st_mtime,
        "modified_ns": after.st_mtime_ns,
        "size": after.st_size,
    }


def add_records(index_path, additions):
    paths = {record["path"] for record in additions}

    def merge(current):
        retained = [record for record in current if not isinstance(record, dict) or source_path(record) not in paths]
        return retained + additions

    return [record for record in update_json(index_path, [], merge) if isinstance(record, dict)]


def update_record(index_path, previous, replacement=None):
    """Replace or remove a single indexed snapshot without overwriting later edits."""
    def merge(current):
        try:
            position = current.index(previous)
        except ValueError:
            raise LookupError("This Vault entry changed. Run Check for changes and try again.") from None
        current[position:position + 1] = [] if replacement is None else [replacement]
        return current

    return [record for record in update_json(index_path, [], merge) if isinstance(record, dict)]
