"""Incremental document chunks, embedding provenance and optional SQLite FTS5."""
from __future__ import annotations

import hashlib
import json
import math
import re
import sqlite3


def ensure_schema(conn):
    for table in ('memories', 'documents'):
        columns = {row[1] for row in conn.execute('PRAGMA table_info(' + table + ')')}
        additions = {'embedding_model': "TEXT NOT NULL DEFAULT ''", 'embedding_dimensions': 'INTEGER NOT NULL DEFAULT 0'}
        if table == 'documents':
            additions.update({'content_hash': "TEXT NOT NULL DEFAULT ''", 'chunk_start': 'INTEGER NOT NULL DEFAULT 0',
                              'chunk_end': 'INTEGER NOT NULL DEFAULT 0', 'chunk_index': 'INTEGER NOT NULL DEFAULT 0'})
        for name, declaration in additions.items():
            if name not in columns:
                conn.execute('ALTER TABLE ' + table + ' ADD COLUMN ' + name + ' ' + declaration)
    conn.execute('CREATE TABLE IF NOT EXISTS e47_schema (key TEXT PRIMARY KEY, value TEXT NOT NULL)')
    try:
        for table, text_column in (('memories', 'content'), ('documents', 'chunk')):
            fts = 'e47_' + table + '_fts'
            conn.execute(f"CREATE VIRTUAL TABLE IF NOT EXISTS {fts} USING fts5({text_column}, content='{table}', content_rowid='id', tokenize='unicode61')")
            conn.executescript(f'''
                CREATE TRIGGER IF NOT EXISTS {fts}_insert AFTER INSERT ON {table} BEGIN
                    INSERT INTO {fts}(rowid,{text_column}) VALUES(new.id,new.{text_column}); END;
                CREATE TRIGGER IF NOT EXISTS {fts}_delete AFTER DELETE ON {table} BEGIN
                    INSERT INTO {fts}({fts},rowid,{text_column}) VALUES('delete',old.id,old.{text_column}); END;
                CREATE TRIGGER IF NOT EXISTS {fts}_update AFTER UPDATE OF {text_column} ON {table} BEGIN
                    INSERT INTO {fts}({fts},rowid,{text_column}) VALUES('delete',old.id,old.{text_column});
                    INSERT INTO {fts}(rowid,{text_column}) VALUES(new.id,new.{text_column}); END;
            ''')
            if not conn.execute('SELECT 1 FROM e47_schema WHERE key=?', (fts,)).fetchone():
                conn.execute(f"INSERT INTO {fts}({fts}) VALUES('rebuild')")
                conn.execute('INSERT INTO e47_schema VALUES(?,?)', (fts, '1'))
        return True
    except sqlite3.OperationalError as exc:
        if 'fts5' not in str(exc).casefold() and 'no such module' not in str(exc).casefold():
            raise
        return False


def candidate_rows(conn, table, profile, query, embedding_model=''):
    if table not in {'memories', 'documents'}:
        raise ValueError('Unsupported search table')
    rows = []
    terms = list(dict.fromkeys(re.findall(r'\w{2,}', str(query).casefold())))[:16]
    if terms:
        expression = ' OR '.join('"' + term.replace('"', '""') + '"' for term in terms)
        fts = 'e47_' + table + '_fts'
        try:
            rows = conn.execute(f'''SELECT t.* FROM {table} t JOIN {fts} ON t.id={fts}.rowid
                                   WHERE {fts} MATCH ? AND t.profile=? ORDER BY bm25({fts}) LIMIT 500''',
                                (expression, profile)).fetchall()
        except sqlite3.OperationalError:
            pass
    # Bounded fallback is available when SQLite has no FTS5. Semantic candidates
    # must be considered even when they share no lexical terms with the query.
    if embedding_model:
        extra = conn.execute(f'SELECT * FROM {table} WHERE profile=? AND embedding_model=? ORDER BY id DESC LIMIT 5000',
                             (profile, embedding_model)).fetchall()
        rows = list(rows) + list(extra)
    if not rows:
        rows = conn.execute(f'SELECT * FROM {table} WHERE profile=? ORDER BY id DESC LIMIT 5000', (profile,)).fetchall()
    clean, seen = [], set()
    for row in rows:
        value = dict(row)
        if value['id'] in seen:
            continue
        seen.add(value['id'])
        if not embedding_model or value.get('embedding_model') != embedding_model:
            value['embedding'] = ''
        clean.append(value)
    return clean


def document_chunks(text, max_chars=2200, overlap=160):
    max_chars = max(200, min(20000, int(max_chars)))
    overlap = max(0, min(int(overlap), max_chars // 4))
    start, length = 0, len(text)
    while start < length:
        end = min(start + max_chars, length)
        if end < length:
            cut = text.rfind('\n\n', start + max_chars // 2, end)
            if cut < 0:
                cut = text.rfind(' ', start + max_chars // 2, end)
            if cut > start:
                end = cut
        if text[start:end].strip():
            yield {'text': text[start:end], 'start': start, 'end': end}
        if end == length:
            break
        start = max(start + 1, end - overlap)


def document_fingerprint(text, max_chars):
    return hashlib.sha256((str(max_chars) + ':160\0' + text).encode('utf-8')).hexdigest()


def vector_metadata(vector, model):
    if not isinstance(vector, (list, tuple)) or not 1 <= len(vector) <= 32768:
        raise ValueError('Invalid embedding vector dimensions')
    values = [float(value) for value in vector]
    if not all(math.isfinite(value) for value in values):
        raise ValueError('Embedding contains a non-finite number')
    return json.dumps(values, allow_nan=False), str(model), len(values)
