"""Continuous, memory-bounded audio capture independent of transcription.

Only worker processes import the optional capture/transcription libraries.
"""
from __future__ import annotations

from collections import deque
import json
import math
import os
from pathlib import Path
import queue
import sys
import threading
import time

from .config import load_voice_settings

PROTOCOL_VERSION = 2
_output_lock = threading.Lock()


def emit(kind, **fields):
    with _output_lock:
        print(json.dumps({'type': kind, 'protocol': PROTOCOL_VERSION,
                          'monotonic': round(time.monotonic(), 4), **fields}, ensure_ascii=False), flush=True)


def read_commands(stream, stop, callback=None):
    """EOF ends capture too; a crashed parent must not leave a live microphone."""
    try:
        while not stop.is_set():
            line = stream.readline(32769)
            if not line:
                break
            if len(line) > 32768:
                emit('error', message='Oversized worker command was rejected.')
                stop.set()
                break
            try:
                item = json.loads(line)
            except (ValueError, TypeError):
                continue
            if not isinstance(item, dict) or not isinstance(item.get('type'), str):
                continue
            if item['type'] == 'stop':
                break
            if callback:
                callback(item)
    finally:
        stop.set()


def watch_parent(stop):
    parent = int(os.environ.get('EDIE_PARENT_PID', '0') or '0')
    if not parent:
        return
    handle = None
    try:
        if os.name == 'nt':
            import ctypes
            from ctypes import wintypes
            kernel = ctypes.WinDLL('kernel32', use_last_error=True)
            kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
            kernel.OpenProcess.restype = wintypes.HANDLE
            kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
            kernel.CloseHandle.argtypes = [wintypes.HANDLE]
            handle = kernel.OpenProcess(0x00100000, False, parent)
            if not handle:
                stop.set()
                return
            while not stop.wait(.25):
                if kernel.WaitForSingleObject(handle, 0) != 258:
                    stop.set()
        else:
            while not stop.wait(.25):
                if os.getppid() != parent:
                    stop.set()
    finally:
        if handle:
            kernel.CloseHandle(handle)


class CapturePump:
    """Hold one recorder open; bound latency even if inference falls behind."""
    def __init__(self, device, stop, sample_rate=16000, frame_size=4000, capacity=32, suppress=None):
        self.device, self.stop = device, stop
        self.sample_rate, self.frame_size = sample_rate, frame_size
        self.frames = queue.Queue(maxsize=capacity)
        self.thread = None
        self.error = None
        self.dropped = 0
        self.suppress = suppress

    def offer(self, frame):
        try:
            self.frames.put_nowait(frame)
        except queue.Full:
            try:
                self.frames.get_nowait()
            except queue.Empty:
                pass
            self.dropped += 1
            try:
                self.frames.put_nowait(frame)
            except queue.Full:
                self.dropped += 1

    def _run(self):
        try:
            import numpy as np
            with self.device.recorder(samplerate=self.sample_rate) as recorder:
                while not self.stop.is_set():
                    frame = np.asarray(recorder.record(numframes=self.frame_size), dtype=np.float32)
                    if frame.ndim == 2:
                        frame = frame.mean(axis=1)
                    if frame.size:
                        self.offer((time.monotonic(), None if self.suppress and self.suppress() else frame.copy()))
        except Exception as exc:
            self.error = exc
        finally:
            self.stop.set()

    def start(self):
        self.thread = threading.Thread(target=self._run, daemon=True, name='EDIE-Continuous-Audio-Capture')
        self.thread.start()
        return self

    def read(self):
        while not self.stop.is_set():
            if self.error:
                raise RuntimeError('Audio device became unavailable: ' + str(self.error)[:240])
            try:
                return self.frames.get(timeout=.25)
            except queue.Empty:
                continue
        if self.error:
            raise RuntimeError('Audio device became unavailable: ' + str(self.error)[:240])
        return None

    def close(self):
        self.stop.set()
        if self.thread:
            self.thread.join(timeout=1)


def rms(samples):
    import numpy as np
    values = np.asarray(samples, dtype=np.float32)
    return float(np.sqrt(np.mean(values * values))) if values.size else 0.0


class SpeechSegmenter:
    """Adaptive energy gate with pre-roll and configurable utterance boundaries."""
    def __init__(self, settings, frame_seconds=.25):
        self.settings = settings
        self.pre_roll = deque(maxlen=max(0, math.ceil(settings.pre_roll_seconds / frame_seconds)))
        self.silence_limit = math.ceil(settings.silence_seconds / frame_seconds)
        self.max_frames = math.ceil(settings.max_utterance_seconds / frame_seconds)
        self.noise = .002
        self.frames = []
        self.silent = 0
        self.started = False

    def reset(self):
        self.frames = []
        self.pre_roll.clear()
        self.silent = 0

    def feed(self, audio, level):
        self.started = False
        threshold = max(self.settings.minimum_level, min(.05, self.noise * 3 + .002))
        if not self.frames:
            if level < threshold:
                self.noise = self.noise * .97 + min(level, .02) * .03
                self.pre_roll.append(audio)
                return None
            self.frames = list(self.pre_roll) + [audio]
            self.pre_roll.clear()
            self.silent = 0
            self.started = True
            return None
        self.frames.append(audio)
        self.silent = self.silent + 1 if level < threshold * .75 else 0
        if self.silent >= self.silence_limit or len(self.frames) >= self.max_frames:
            completed = self.frames
            self.frames = []
            self.silent = 0
            return completed
        return None


def _settings():
    data = Path(os.environ.get('EDIE_DATA_DIR', Path.cwd() / 'edie_data'))
    return load_voice_settings(data, os.environ.get('EDIE_ACTIVE_PROFILE', 'Default'))


def _whisper(model_name, cache_dir, settings):
    from faster_whisper import WhisperModel
    emit('status', status='LOADING CACHED LOCAL WHISPER MODEL · ' + model_name)
    options = dict(download_root=str(cache_dir), local_files_only=True)
    try:
        return WhisperModel(model_name, device=settings.backend,
                            compute_type='float16' if settings.backend == 'cuda' else 'int8', **options)
    except Exception as first:
        if settings.backend == 'cuda':
            try:
                model = WhisperModel(model_name, device='cpu', compute_type='int8', **options)
                emit('status', status='GPU unavailable; using the cached local model on CPU.')
                return model
            except Exception:
                pass
        raise RuntimeError('The local speech model could not be loaded. Open Voice reliability settings, '
                           'download the selected Whisper model once, then retry. ' + type(first).__name__) from first


def _transcribe(model, frames, settings, model_name):
    import numpy as np
    if not frames:
        return
    audio = np.concatenate(frames).astype(np.float32, copy=False)
    if len(audio) < 4000 or rms(audio) < settings.minimum_level * .5:
        return
    language = None if settings.language == 'auto' else settings.language
    if language is None and model_name.endswith('.en'):
        language = 'en'
    started = time.monotonic()
    segments, info = model.transcribe(audio, language=language, vad_filter=False,
                                      beam_size=2, condition_on_previous_text=False)
    text = ' '.join(segment.text.strip() for segment in segments if segment.text.strip()).strip()
    if text:
        emit('transcript', text=text[:9000], language=str(getattr(info, 'language', 'unknown')),
             audio_seconds=round(len(audio) / 16000, 2), transcription_ms=round((time.monotonic() - started) * 1000))


def capture_main(mode, argv=None):
    args = list(sys.argv[1:] if argv is None else argv)
    stop = threading.Event()
    tts_active = threading.Event()
    def command(item):
        if item.get('type') == 'tts_state':
            (tts_active.set if item.get('active') is True else tts_active.clear)()
    threading.Thread(target=read_commands, args=(sys.stdin, stop, command), daemon=True).start()
    threading.Thread(target=watch_parent, args=(stop,), daemon=True).start()
    pump = None
    try:
        settings = _settings()
        if mode == 'system':
            if len(args) < 4:
                raise ValueError('Usage: worker DEVICE MODEL CHUNK_SECONDS CACHE_DIR')
            device_name, model_name = args[:2]
            seconds, cache_dir = max(4, min(12, int(args[2]))), Path(args[3])
        else:
            if len(args) < 2:
                raise ValueError('Usage: worker MODEL CACHE_DIR [headphones|speakers]')
            model_name, cache_dir = args[0], Path(args[1])
        cache_dir.mkdir(parents=True, exist_ok=True)
        model = _whisper(model_name, cache_dir, settings)
        if stop.is_set():
            return 0
        import soundcard as sc
        if mode == 'system':
            device = next((d for d in sc.all_microphones(include_loopback=True)
                           if getattr(d, 'isloopback', False) and device_name in {str(d.name), str(d.id)}), None)
        elif settings.microphone:
            device = next((d for d in sc.all_microphones() if settings.microphone in {str(d.name), str(d.id)}), None)
        else:
            device = sc.default_microphone()
        if device is None:
            raise RuntimeError('The selected audio device is unavailable. Reconnect it or select another device in Voice reliability settings.')
        headphones_mode = len(args) < 3 or args[2].casefold() != 'speakers'
        pump = CapturePump(device, stop, suppress=(lambda: tts_active.is_set() and not headphones_mode) if mode != 'system' else None).start()
        segmenter = SpeechSegmenter(settings)
        emit('ready', status='LISTENING · CONTINUOUS LOCAL CAPTURE', device=str(device.name)[:160])
        emit('status', status='LISTENING · CONTINUOUS LOCAL CAPTURE')
        frames, reported_drops = [], 0
        last_heartbeat = time.monotonic()
        while not stop.is_set():
            item = pump.read()
            if item is None:
                break
            captured_at, audio = item
            if audio is None:
                segmenter.reset()
                continue
            if pump.dropped != reported_drops:
                reported_drops = pump.dropped
                emit('status', status='Speech processing fell behind; oldest audio was dropped.', dropped_frames=reported_drops)
                frames = []
                segmenter.reset()
            if time.monotonic() - captured_at > 8:
                continue
            if time.monotonic() - last_heartbeat >= 5:
                emit('heartbeat', buffered_frames=pump.frames.qsize(), dropped_frames=pump.dropped)
                last_heartbeat = time.monotonic()
            if mode == 'system':
                frames.append(audio)
                if len(frames) >= seconds * 4:
                    _transcribe(model, frames, settings, model_name)
                    frames = []
            else:
                if tts_active.is_set() and not headphones_mode:
                    segmenter.reset()
                    continue
                completed = segmenter.feed(audio, rms(audio))
                if segmenter.started:
                    emit('speech_started')
                if completed:
                    emit('status', status='TRANSCRIBING LOCALLY · CAPTURE CONTINUES')
                    _transcribe(model, completed, settings, model_name)
                    emit('status', status='LISTENING · CONTINUOUS LOCAL CAPTURE')
        return 0
    except KeyboardInterrupt:
        return 0
    except Exception as exc:
        emit('error', message=type(exc).__name__ + ': ' + str(exc)[:1000])
        return 1
    finally:
        stop.set()
        if pump:
            pump.close()
