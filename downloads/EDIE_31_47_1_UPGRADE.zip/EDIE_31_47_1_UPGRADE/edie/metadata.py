"""Release identity used by launchers, diagnostics and the desktop window."""
VERSION = "31.47.1"
RELEASE_NAME = "WINDOWS SQLITE HANDLE FIX"
SOURCE_FILENAME = "EDIE_31_47_1_IMPROVED.py"
MINIMUM_PYTHON = (3, 11)
