"""Stable command line and preflight without loading the desktop for simple actions."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
import tempfile

from .config import data_directory
from .metadata import VERSION, RELEASE_NAME, SOURCE_FILENAME


def verify_package(root):
    manifest = root / 'SHA256SUMS.json'
    body = json.loads(manifest.read_text(encoding='utf-8'))
    checked = 0
    for relative, expected in body['files'].items():
        path = (root / relative).resolve()
        if root.resolve() not in path.parents or not path.is_file() or path.is_symlink():
            raise ValueError('Missing or unsafe packaged file: ' + relative)
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError('Packaged file checksum mismatch: ' + relative)
        checked += 1
    return {'version': body['version'], 'files_verified': checked,
            'note': 'Package integrity check; this is not a publisher digital signature.'}


def main(argv=None):
    arguments = list(sys.argv[1:] if argv is None else argv)
    root = Path(__file__).resolve().parent.parent
    data = data_directory(root)
    try:
        if '--version' in arguments:
            print(f'EDIE {VERSION} · {RELEASE_NAME}\nPython: {sys.executable}\nData folder: {data}')
            return 0
        if '--data-dir' in arguments:
            print(data)
            return 0
        if '--open-data' in arguments:
            data.mkdir(parents=True, exist_ok=True)
            if os.name == 'nt':
                os.startfile(str(data))
            else:
                print(data)
            return 0
        if '--verify-package' in arguments:
            print(json.dumps(verify_package(root), indent=2))
            return 0
        if '--install-voice-model' in arguments:
            from .model_setup import install
            install(data, root)
            return 0
        if '--upgrade-test' in arguments or '--self-test' in arguments:
            with tempfile.TemporaryDirectory(prefix='edie-release-tests-') as temporary:
                env = os.environ.copy()
                env['EDIE_DATA_DIR'] = str(Path(temporary) / 'test-data')
                env['PYTHONDONTWRITEBYTECODE'] = '1'
                if '--self-test' in arguments:
                    result = subprocess.run([sys.executable, '-B', str(root / SOURCE_FILENAME), '--self-test'], cwd=root, env=env)
                    if result.returncode:
                        return result.returncode
                return subprocess.run([sys.executable, '-B', '-m', 'unittest', 'discover', '-s', str(root / 'tests'), '-v'],
                                      cwd=root, env=env).returncode
        if not importlib.util.find_spec('tkinter'):
            print('Tkinter is missing from this Python installation. Install Python with Tcl/Tk support, or set EDIE_PYTHON to your working interpreter.', file=sys.stderr)
            return 2
        if not (root / SOURCE_FILENAME).is_file() or not (root / 'assets' / 'brain.png').is_file():
            print('EDIE files are missing. Extract the complete ZIP into a new folder before starting.', file=sys.stderr)
            return 2
        data.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryFile(dir=data):
            pass
        previous = sys.argv
        sys.argv = [str(root / SOURCE_FILENAME), *arguments]
        try:
            runpy.run_path(str(root / SOURCE_FILENAME), run_name='__main__')
        finally:
            sys.argv = previous
        return 0
    except KeyboardInterrupt:
        return 130
    except (OSError, ValueError, ImportError, subprocess.SubprocessError) as exc:
        print('EDIE could not complete this action: ' + type(exc).__name__ + ': ' + str(exc), file=sys.stderr)
        print('Run START_EDIE.bat --self-test for isolated checks, or use --safe-mode for desktop recovery.', file=sys.stderr)
        return 1
