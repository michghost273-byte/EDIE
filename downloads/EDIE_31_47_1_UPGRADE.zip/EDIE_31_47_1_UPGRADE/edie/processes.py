"""Reap child processes without blocking Tk's event loop."""
import subprocess
import threading


def stop_process(process, graceful=True):
    if process is None:
        return
    if graceful and process.poll() is None and getattr(process, 'stdin', None) is not None:
        try:
            process.stdin.write('{"type":"stop"}\n')
            process.stdin.flush()
        except (OSError, ValueError):
            pass
    elif process.poll() is None:
        try: process.terminate()
        except OSError: pass
    def reap():
        try:
            process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            try: process.kill(); process.wait(timeout=2)
            except (OSError, subprocess.TimeoutExpired): pass
        finally:
            for name in ('stdin', 'stdout', 'stderr'):
                handle = getattr(process, name, None)
                if handle:
                    try: handle.close()
                    except (OSError, ValueError): pass
    threading.Thread(target=reap, name='EDIE-Child-Cleanup', daemon=True).start()
