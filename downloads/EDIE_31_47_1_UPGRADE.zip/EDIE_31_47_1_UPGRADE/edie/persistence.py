"""Validated JSON reads and serialised, durable atomic writes.

The lock covers the whole read/modify/write operation when update_json is used.
Atomic writes alone cannot merge changes made by independently read callers.
"""
from __future__ import annotations

import contextlib
import copy
import json
import os
from pathlib import Path
import tempfile
import threading
import time

_registry_lock = threading.Lock()
_locks: dict[str, threading.RLock] = {}


def _thread_lock(path):
    key = os.path.normcase(str(Path(path).resolve()))
    with _registry_lock:
        return _locks.setdefault(key, threading.RLock())


@contextlib.contextmanager
def file_lock(path, timeout=10):
    """Coordinate independent EDIE processes without locking the replaced file."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with _thread_lock(path):
        lock_path = path.with_name(path.name + '.lock')
        with lock_path.open('a+b') as handle:
            if handle.tell() == 0:
                handle.write(b'\0')
                handle.flush()
            deadline = time.monotonic() + timeout
            while True:
                try:
                    handle.seek(0)
                    if os.name == 'nt':
                        import msvcrt
                        msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                    else:
                        import fcntl
                        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except (BlockingIOError, OSError):
                    if time.monotonic() >= deadline:
                        raise TimeoutError('Another EDIE process is updating ' + path.name)
                    time.sleep(0.025)
            try:
                yield
            finally:
                handle.seek(0)
                if os.name == 'nt':
                    import msvcrt
                    msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def read_json(path, default):
    """Reject mismatched top-level containers and return an independent default."""
    try:
        value = json.loads(Path(path).read_text(encoding='utf-8-sig'))
        if isinstance(default, dict) and not isinstance(value, dict):
            return copy.deepcopy(default)
        if isinstance(default, list) and not isinstance(value, list):
            return copy.deepcopy(default)
        return value
    except (OSError, ValueError, TypeError, UnicodeError):
        return copy.deepcopy(default)


def _atomic_write(path, value):
    path = Path(path)
    payload = json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False)
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix='.' + path.name + '.', suffix='.tmp', dir=path.parent)
    try:
        with os.fdopen(descriptor, 'w', encoding='utf-8', newline='\n') as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        for attempt in range(5):
            try:
                os.replace(temporary, path)
                break
            except PermissionError:
                if attempt == 4:
                    raise
                time.sleep(0.025 * (attempt + 1))
        if os.name != 'nt':
            descriptor = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
    finally:
        try:
            Path(temporary).unlink(missing_ok=True)
        except OSError:
            pass


def write_json(path, value):
    with file_lock(path):
        _atomic_write(path, value)


def update_json(path, default, update):
    """Apply a callable to the latest value while holding both process locks."""
    with file_lock(path):
        value = update(read_json(path, default))
        _atomic_write(path, value)
        return value
