"""Typed, profile-scoped voice preferences; optional packages are loaded elsewhere."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import math
import os
from pathlib import Path
import re

from .persistence import read_json, update_json


def data_directory(application_dir=None):
    application_dir = Path(application_dir or Path(__file__).resolve().parent.parent)
    override = os.environ.get('EDIE_DATA_DIR', '').strip()
    return Path(override).expanduser().resolve() if override else application_dir / 'edie_data'


@dataclass(frozen=True)
class VoiceSettings:
    language: str = 'auto'
    microphone: str = ''
    silence_seconds: float = 1.0
    max_utterance_seconds: float = 20.0
    pre_roll_seconds: float = 0.5
    minimum_level: float = 0.006
    backend: str = 'cpu'
    rate: int = 178
    volume: float = 0.85
    voice: str = ''

    @classmethod
    def from_mapping(cls, value):
        if not isinstance(value, dict):
            return cls()
        default = cls()
        clean = {}
        ranges = {'silence_seconds': (.4, 3), 'max_utterance_seconds': (5, 60),
                  'pre_roll_seconds': (0, 1), 'minimum_level': (.001, .05),
                  'rate': (110, 240), 'volume': (0, 1)}
        for key, (low, high) in ranges.items():
            try:
                raw = value.get(key, getattr(default, key))
                if isinstance(raw, bool):
                    continue
                number = float(raw)
                if math.isfinite(number) and low <= number <= high:
                    clean[key] = int(number) if key == 'rate' else number
            except (TypeError, ValueError, OverflowError):
                continue
        language = value.get('language', 'auto')
        if isinstance(language, str) and re.fullmatch(r'auto|[a-z]{2,3}(?:-[a-z]{2})?', language):
            clean['language'] = language
        if value.get('backend') in {'cpu', 'cuda'}:
            clean['backend'] = value['backend']
        for key in ('microphone', 'voice'):
            raw = value.get(key, '')
            if isinstance(raw, str) and '\x00' not in raw:
                clean[key] = raw[:300]
        return cls(**clean)


def load_voice_settings(data_dir, profile='Default'):
    body = read_json(Path(data_dir) / 'voice47_settings.json', {})
    profiles = body.get('profiles', {})
    return VoiceSettings.from_mapping(profiles.get(str(profile), {})) if isinstance(profiles, dict) else VoiceSettings()


def save_voice_settings(data_dir, profile, settings):
    settings = VoiceSettings.from_mapping(asdict(settings) if isinstance(settings, VoiceSettings) else settings)
    def update(body):
        profiles = body.get('profiles')
        if not isinstance(profiles, dict):
            profiles = {}
        profiles[str(profile)] = asdict(settings)
        return {'schema_version': 1, 'profiles': profiles}
    update_json(Path(data_dir) / 'voice47_settings.json', {}, update)
    return settings


def worker_environment(data_dir, profile):
    env = os.environ.copy()
    env['EDIE_DATA_DIR'] = str(Path(data_dir).resolve())
    env['EDIE_ACTIVE_PROFILE'] = str(profile)
    env['EDIE_APP_DIR'] = str(Path(__file__).resolve().parent.parent)
    env['EDIE_PARENT_PID'] = str(os.getpid())
    env['PYTHONUNBUFFERED'] = '1'
    return env
