"""Standard keyboard-accessible controls for the new reliability services."""
from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import secrets
import sys
import threading

from .backups import create_backup, stage_restore, verify_backup
from .config import load_voice_settings, save_voice_settings, worker_environment
from .metadata import VERSION, RELEASE_NAME
from .ollama_status import read_model_list, describe_status_failure


def pause_capture(app, block_new=True):
    if block_new:
        app._edie47_capture_paused = True
    app._edie47_resume_wake_after_duplex = False
    voice = getattr(app, '_edie41_voice', None)
    if voice:
        voice.mute()
    environment = app._edie47_services.environment
    for name, args in (('_edie311811_stop_duplex', (app, 'Microphone paused')),
                       ('_edie316_audio_stop', (app, False)),
                       ('_edie_live_awareness_stop', (app, False))):
        function = environment.get(name)
        if callable(function):
            try: function(*args)
            except Exception as exc:
                app._edie47_services.log.warning('Capture stop failed: %s', type(exc).__name__)
    app.status.set('Capture paused. Saved permissions have not changed.')


def resume_capture_controls(app):
    app._edie47_capture_paused = False
    app.status.set('Capture controls available. Start the session you want; saved permissions still apply.')


def install_navigation(app):
    import tkinter as tk
    root = app.root

    def open_centre(_event=None):
        app.edie41_improvement_inbox()
        return 'break'

    try:
        existing = root.cget('menu')
        menu = root.nametowidget(existing) if existing else tk.Menu(root)
        navigation = tk.Menu(menu, tearoff=False)
        routes = [('Home', lambda: app.pages.select(app.home_page)),
                  ('Conversation', lambda: app.pages.select(app.chat_page)),
                  ('Tasks', app.mission_control), ('Memory', app.memory_explorer_panel),
                  ('Voice', app._voice_panel), ('Settings', app._settings_panel),
                  ('Voice and reliability', lambda: open_panel(app))]
        for label, callback in routes:
            navigation.add_command(label=label, command=callback)
        navigation.add_separator()
        navigation.add_command(label='Find an action…', command=app.command_palette, accelerator='Ctrl+K')
        navigation.add_separator()
        navigation.add_command(label='Pause microphones and observation', command=lambda: pause_capture(app))
        navigation.add_command(label='Allow capture controls again', command=lambda: resume_capture_controls(app))
        menu.add_cascade(label='EDIE', menu=navigation)
        menu.add_command(label='Self-Improvement Centre', command=open_centre, accelerator='Ctrl+Shift+U')
        root.configure(menu=menu)
        app._edie47_menu = menu
        root.bind('<Control-Shift-R>', lambda _event: open_panel(app), add='+')
        root.bind('<Control-Shift-U>', open_centre, add='+')
    except Exception as exc:
        app._edie47_services.log.warning('Navigation installation failed: %s', type(exc).__name__)


def open_panel(app):
    import tkinter as tk
    from tkinter import ttk, messagebox, filedialog
    services = app._edie47_services
    existing = getattr(app, '_edie47_window', None)
    if existing is not None and existing.winfo_exists():
        existing.lift()
        return existing
    window = tk.Toplevel(app.root)
    app._edie47_window = window
    window.title('EDIE ' + VERSION + ' · Voice and reliability')
    window.geometry('900x720')
    window.minsize(700, 560)
    window.bind('<Escape>', lambda _event: window.destroy())
    owner = str(app.active_profile)
    body = ttk.Frame(window, padding=18)
    body.pack(fill='both', expand=True)
    ttk.Label(body, text='Voice and reliability', font=('Segoe UI', 18, 'bold')).pack(anchor='w')
    ttk.Label(body, text='Profile: ' + owner + ' · EDIE ' + VERSION).pack(anchor='w', pady=(3, 12))
    notebook = ttk.Notebook(body)
    notebook.pack(fill='both', expand=True)
    voice_tab = ttk.Frame(notebook)
    voice_canvas = tk.Canvas(voice_tab, highlightthickness=0,
                             bg=ttk.Style(window).lookup('TFrame', 'background') or '#0b1320')
    voice_scroll = ttk.Scrollbar(voice_tab, orient='vertical', command=voice_canvas.yview)
    voice_canvas.configure(yscrollcommand=voice_scroll.set)
    voice_scroll.pack(side='right', fill='y')
    voice_canvas.pack(side='left', fill='both', expand=True)
    voice = ttk.Frame(voice_canvas, padding=14)
    voice_item = voice_canvas.create_window((0, 0), window=voice, anchor='nw')
    voice.bind('<Configure>', lambda _event: voice_canvas.configure(scrollregion=voice_canvas.bbox('all')))
    voice_canvas.bind('<Configure>', lambda event: voice_canvas.itemconfigure(voice_item, width=event.width))
    health = ttk.Frame(notebook, padding=14)
    backups = ttk.Frame(notebook, padding=14)
    about = ttk.Frame(notebook, padding=14)
    for panel, title in [(voice_tab, 'Voice'), (health, 'Health'), (backups, 'Backups'), (about, 'About')]:
        notebook.add(panel, text=title)
    status = tk.StringVar(value='Ready. Settings apply to the next voice session.')
    ttk.Label(body, textvariable=status, wraplength=800).pack(fill='x', pady=(12, 0))

    def visible():
        return not services.closed and bool(window.winfo_exists())

    def work(label, function, done=None):
        status.set(label + '…')
        def run():
            try:
                value = function()
                def finish(value=value):
                    if visible():
                        status.set(label + ' complete.')
                        if done: done(value)
                app.root.after(0, finish)
            except Exception as exc:
                detail = type(exc).__name__ + ': ' + str(exc)[:1000]
                def fail(detail=detail):
                    if visible():
                        status.set(label + ' failed.')
                        messagebox.showerror(label, detail, parent=window)
                try: app.root.after(0, fail)
                except RuntimeError: pass
        threading.Thread(target=run, daemon=True, name='EDIE-Reliability-Action').start()

    settings = load_voice_settings(services.data, owner)
    values = {key: tk.StringVar(value=str(value)) for key, value in asdict(settings).items()}
    rows = [('Microphone name or ID (blank uses default)', 'microphone', None),
            ('Whisper language', 'language', ('auto', 'en', 'es', 'fr', 'de', 'it', 'pt', 'nl', 'pl', 'ja', 'zh')),
            ('Pause ending an utterance (seconds)', 'silence_seconds', None),
            ('Maximum utterance (seconds)', 'max_utterance_seconds', None),
            ('Pre-roll (seconds)', 'pre_roll_seconds', None),
            ('Minimum speech level', 'minimum_level', None),
            ('Whisper processing', 'backend', ('cpu', 'cuda')),
            ('Speech rate (110–240)', 'rate', None),
            ('Volume (0–1)', 'volume', None),
            ('Installed SAPI voice ID (blank uses default)', 'voice', None)]
    for row, (label, key, choices) in enumerate(rows):
        ttk.Label(voice, text=label).grid(row=row, column=0, sticky='w', pady=4, padx=(0, 14))
        field = ttk.Combobox(voice, textvariable=values[key], values=choices, state='readonly') if choices else ttk.Entry(voice, textvariable=values[key])
        field.grid(row=row, column=1, sticky='ew', pady=4)
    voice.columnconfigure(1, weight=1)
    def save():
        if str(app.active_profile) != owner:
            messagebox.showinfo('Profile changed', 'Close this window and reopen it for the current profile.', parent=window)
            return
        raw = {key: value.get() for key, value in values.items()}
        try:
            # Reject mistyped numbers instead of silently changing the user's input.
            limits = {'silence_seconds': (.4, 3), 'max_utterance_seconds': (5, 60),
                      'pre_roll_seconds': (0, 1), 'minimum_level': (.001, .05), 'rate': (110, 240), 'volume': (0, 1)}
            for key, (low, high) in limits.items():
                number = float(raw[key])
                if not low <= number <= high:
                    raise ValueError(key.replace('_', ' ') + f' must be between {low} and {high}.')
            saved = save_voice_settings(services.data, owner, raw)
            app._edie42_voice_rate = saved.rate
            status.set('Voice settings saved for ' + owner + '. Restart active voice sessions to apply capture changes.')
        except (ValueError, OSError) as exc:
            messagebox.showerror('Settings not saved', str(exc), parent=window)
    ttk.Button(voice, text='Save voice settings', command=save).grid(row=10, column=0, sticky='w', pady=12)
    ttk.Button(voice, text='Open voice controls', command=app._voice_panel).grid(row=10, column=1, sticky='w')
    model = tk.StringVar(value='base.en')
    ttk.Label(voice, text='Download a Whisper model once for offline use').grid(row=11, column=0, sticky='w')
    ttk.Combobox(voice, textvariable=model, values=('tiny.en', 'base.en', 'small.en', 'tiny', 'base', 'small'), state='readonly').grid(row=11, column=1, sticky='ew')
    def prepare_model():
        if not app._permission_enabled('application_installation') or getattr(app, '_lockdown_active', False):
            messagebox.showinfo('Installation permission required', 'Enable application installation in Permissions before downloading a speech model.', parent=window)
            return
        chosen = model.get()
        status.set('Preparing the private speech runtime…')
        def after_runtime(ok, detail):
            if not ok:
                status.set('Speech runtime not ready: ' + str(detail)[-200:])
                return
            python = services.environment['_edie311810_runtime_python']()
            if python is None:
                status.set('The private speech interpreter is unavailable.')
                return
            command = [str(python), '-c',
                       'import sys; from faster_whisper import WhisperModel; '
                       'WhisperModel(sys.argv[1], device="cpu", compute_type="int8", download_root=sys.argv[2]); print("Model prepared.")',
                       chosen, str(services.data / 'whisper_cache')]
            env = worker_environment(services.data, owner)
            env['HF_HUB_DISABLE_PROGRESS_BARS'] = '1'
            work('Downloading ' + chosen, lambda: services.run_process(command, env=env),
                 lambda _: status.set(chosen + ' is cached. Voice capture can now run offline.'))
        services.environment['_edie311810_ensure_audio_runtime'](app, after_runtime, force=True)
    ttk.Button(voice, text='Download selected model', command=prepare_model).grid(row=12, column=0, sticky='w', pady=10)
    ttk.Label(voice, text='Microphone audio stays in memory. Recognised text becomes normal chat history.\nCUDA falls back to CPU if unavailable. English-only .en models require English speech.',
              wraplength=760).grid(row=13, column=0, columnspan=2, sticky='w', pady=4)
    def prepare_speech():
        if not app._permission_enabled('application_installation') or getattr(app, '_lockdown_active', False):
            messagebox.showinfo('Installation permission required', 'Enable application installation in Permissions before preparing speech output.', parent=window)
            return
        status.set('Preparing optional local speech output…')
        services.environment['_edie311811_ensure_tts'](app,
            lambda ok, detail: status.set('Local speech output is ready.' if ok else str(detail)[-300:]), force=True)
    ttk.Button(voice, text='Prepare local speech output', command=prepare_speech).grid(row=14, column=0, sticky='w', pady=10)
    ttk.Button(voice, text='Pause microphones and observation', command=lambda: pause_capture(app)).grid(row=14, column=1, sticky='w')

    output = tk.Text(health, wrap='word', height=20)
    output.pack(fill='both', expand=True)
    def show(value):
        output.configure(state='normal')
        output.delete('1.0', 'end')
        output.insert('1.0', json.dumps(value, indent=2, ensure_ascii=False, default=str))
        output.configure(state='disabled')
    def inspect():
        def probe():
            report = services.status()
            report['main_python'] = sys.executable
            report['data_directory'] = str(services.data)
            report['optional_main_packages'] = {name: bool(importlib.util.find_spec(name)) for name in ('vosk', 'sounddevice', 'pyttsx3', 'psutil')}
            try:
                models = read_model_list('http://127.0.0.1:11434/api/tags')
                report['ollama'] = {'reachable': True, 'models': [row.get('name') or row.get('model') for row in models]}
            except Exception as exc:
                state, description = describe_status_failure(exc)
                report['ollama'] = {
                    'reachable': False if state == 'offline' else None,
                    'status': state,
                    'detail': description,
                    'error': type(exc).__name__,
                    'next_action': 'Start Ollama and run the check again.' if state == 'offline' else 'Run the check again in a few seconds.',
                }
            return report
        work('Checking local services', probe, show)
    ttk.Button(health, text='Check local services', command=inspect).pack(anchor='w', pady=(10, 0))
    show(services.status())

    ttk.Label(backups, text='Full backups contain every EDIE profile and personal conversation data.\nDownloaded models, runtimes and OS credentials are excluded. Keep ZIP files private.', wraplength=760).pack(anchor='w', pady=(0, 12))
    backup_output = tk.Text(backups, wrap='word', height=16)
    backup_output.pack(fill='both', expand=True)
    def backup_message(value):
        backup_output.delete('1.0', 'end')
        backup_output.insert('1.0', str(value))
    def make_backup():
        def done(result):
            path, manifest = result
            backup_message(f'Backup: {path}\nStatus: {manifest["status"]}\nFiles: {len(manifest["entries"])}\nSkipped: {len(manifest["skipped"])}\n\n' + json.dumps(manifest['skipped'], indent=2))
        work('Creating full backup', lambda: create_backup(services.data), done)
    def choose_verify():
        path = filedialog.askopenfilename(parent=window, title='Choose a full EDIE backup', filetypes=[('EDIE ZIP backup', '*.zip')])
        if path:
            work('Verifying backup', lambda: verify_backup(path), lambda result: backup_message(json.dumps(result, indent=2)))
    def choose_stage():
        path = filedialog.askopenfilename(parent=window, title='Choose a full EDIE backup', filetypes=[('EDIE ZIP backup', '*.zip')])
        if path:
            destination = services.data / 'recovery_staging' / ('reliability_' + datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_') + secrets.token_hex(3))
            work('Rehearsing recovery', lambda: stage_restore(path, destination),
                 lambda target: backup_message('Verified files restored into a new staging folder:\n' + str(target) + '\n\nYour live data has not been overwritten.'))
    bar = ttk.Frame(backups)
    bar.pack(fill='x', pady=(10, 0))
    for label, command in [('Create full backup', make_backup), ('Verify backup', choose_verify), ('Rehearse recovery', choose_stage)]:
        ttk.Button(bar, text=label, command=command).pack(side='left', padx=(0, 8))
    ttk.Label(about, text='EDIE ' + VERSION + '\n' + RELEASE_NAME, font=('Segoe UI', 15, 'bold')).pack(anchor='w', pady=(0, 14))
    ttk.Label(about, text='This upgrade adds tested persistence, profile-safe automation, continuous audio capture,\ninterruptible speech, draft recovery and manifest-verified full backups.\n\nThe existing workspaces remain available through the command palette.\nOpen EDIE > Voice and reliability, or press Ctrl+Shift+R, to return here.\n\nLive microphone, device acoustics, SAPI and Windows installation still require\nverification on the target Windows computer. See IMPROVEMENTS.md for the\nitem-by-item status of the complete improvement backlog.', wraplength=760, justify='left').pack(anchor='w')
    return window
