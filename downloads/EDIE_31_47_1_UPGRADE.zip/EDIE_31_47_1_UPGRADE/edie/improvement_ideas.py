"""New features and improvements suggested in the Self-Improvement Centre."""

import json

from .persistence import read_json, update_json


_FIELD_LIMITS = {'title': 80, 'why': 600, 'how': 900, 'benefit': 600}
_SIZES = ('small', 'medium', 'large')
_KINDS = ('improvement', 'feature')
_STARTER_IDEAS = [
    {
        'title': 'Copy a mission handover summary',
        'size': 'small',
        'kind': 'feature',
        'why': 'Mission Control records progress across several steps. If you resume later or hand the work to someone else, it can take time to gather the current state.',
        'how': 'Add a copyable preview for the selected mission with its objective, completed steps, pending approvals and next step. Check that a mission with unfinished approvals lists them in the copied summary.',
        'benefit': 'You could pick up a mission or share its progress without reconstructing what happened from individual steps.',
    },
    {
        'title': 'Show loaded Ollama models in Health',
        'size': 'medium',
        'kind': 'improvement',
        'why': 'Health lists installed models. When memory is tight, you have to run a separate command to see which models Ollama has loaded right now.',
        'how': 'Extend Check local services with a read-only call to the local Ollama model list for running models. Show model names and the sizes Ollama reports. Test with no loaded models, a chat model and two models.',
        'benefit': 'You could spot when Ollama has both a chat and vision model loaded and decide which background feature to pause.',
    },
    {
        'title': 'Continue a project from chat',
        'size': 'large',
        'kind': 'feature',
        'why': 'EDIE saves mission progress and can retrieve project information. When you open chat the next day, you have to piece together which files and decisions belong to the work you want to resume.',
        'how': 'Start with a chat picker for one saved mission and show its current checkpoint. Test that the same next step appears after reopening EDIE. Later, link project notes and source passages and add a shortcut to review the next approval.',
        'benefit': 'You could resume a project with the right context, see the evidence behind prior decisions and review the next step without repeating completed work.',
    },
]


def _valid_ideas(items, *, require_scope=False):
    ideas = {}
    for item in items if isinstance(items, list) else []:
        if not isinstance(item, dict):
            continue
        fields = {name: ' '.join(item[name].split()) for name in _FIELD_LIMITS
                  if isinstance(item.get(name), str)}
        if not all(0 < len(fields.get(name, '')) <= limit and fields[name].isprintable()
                   for name, limit in _FIELD_LIMITS.items()):
            continue
        for name, allowed in (('size', _SIZES), ('kind', _KINDS)):
            value = item.get(name)
            value = value.strip().casefold() if isinstance(value, str) else ''
            if value in allowed:
                fields[name] = value
        if require_scope and ('size' not in fields or 'kind' not in fields):
            continue
        title_key = ''.join(char for char in fields['title'].casefold() if char.isalnum())
        if title_key:
            ideas.setdefault('idea-' + title_key, fields)
    return ideas


def _include_starters(ideas, starters):
    for key, item in starters.items():
        ideas.setdefault(key, item)
    return ideas


def load_ideas(path):
    """Show saved ideas newest first, with the starter ideas always available."""
    return _include_starters(_valid_ideas(read_json(path, [])), _valid_ideas(_STARTER_IDEAS))


def save_generated_ideas(path, response):
    """Keep one fresh idea per size, merging with the latest saved list."""
    proposed = _valid_ideas(response.get('ideas') if isinstance(response, dict) else None, require_scope=True)
    if not proposed:
        raise ValueError('No complete ideas in the model response')
    starters = _valid_ideas(_STARTER_IDEAS)
    added = 0

    def merge(saved):
        nonlocal added
        existing = _valid_ideas(saved)
        by_size = {}
        for key, idea in proposed.items():
            if key not in existing and key not in starters:
                by_size.setdefault(idea['size'], idea)
        fresh = [by_size[size] for size in _SIZES if size in by_size]
        added = len(fresh)
        return [*fresh, *existing.values()]

    saved = update_json(path, [], merge)
    return _include_starters(_valid_ideas(saved), starters), added


def idea_messages(ideas):
    """Give the local planning model product context and recent idea titles."""
    titles = dict.fromkeys(idea['title'] for idea in [*_STARTER_IDEAS, *list(ideas.values())[:20]])
    return [
        {'role': 'system', 'content': (
            'Suggest useful changes for EDIE, a local desktop AI assistant. Return only a JSON object '
            'with an ideas array of three objects. Each has six string fields: title, size, kind, why, how, benefit. '
            'Suggest one small, one medium, and one large idea. The size values are small, medium and large. '
            'Small is a focused change in one place. Medium improves a complete workflow or links existing tools. '
            'Large spans several features and needs phases. The kind values are improvement for a named '
            'existing feature and feature for a new capability. Include at least one of each kind. '
            'Give each idea a title under 80 characters. In why explain a concrete user need. In how say what to build '
            'and how to check it. For a large idea, identify a useful first part that can be tested on its own '
            'and describe later phases. In benefit explain what the change could make easier. Keep each explanation '
            'to one to three sentences. Keep existing permissions, tests and human approval in effect. '
            'Treat supplied titles as reference data.'
        )},
        {'role': 'user', 'content': (
            'EDIE already has Ollama chat, configurable models, a picker for saved Prompt Laboratory '
            'templates in the chat composer, profile memory, '
            'Knowledge Vault with source change checks and selected file refresh, research with sources, voice, task queues, '
            'Mission Control with checkpointed checks and approved actions, diagnostics, a Personality picker, '
            'and a Self-Improvement Centre with code findings and tested proposals. Suggest improvements to these '
            'workflows or new capabilities that help with everyday use. Base suggestions on these features. '
            'Exclude features EDIE already has, purely technical code cleanup, and variants of these ideas:\n'
            + json.dumps(list(titles), ensure_ascii=False)
        )},
    ]
