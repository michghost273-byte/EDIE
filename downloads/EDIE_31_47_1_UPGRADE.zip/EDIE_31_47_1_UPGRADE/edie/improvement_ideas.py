"""Feature ideas for the Self-Improvement Centre, stored as plain text."""

import json

from .persistence import read_json, update_json


_FIELD_LIMITS = {'title': 80, 'why': 600, 'how': 900, 'benefit': 600}
_STARTER_IDEAS = [
    {
        'title': 'Copy a mission handover summary',
        'why': 'Mission Control records progress across several steps. If you resume later or hand the work to someone else, it can take time to gather the current state.',
        'how': 'Add a handover preview for the selected mission. Include the objective, completed steps, pending approvals, and the next step. Let the user review and copy the summary.',
        'benefit': 'You could pick up a mission or share its progress without reconstructing what happened from individual steps.',
    },
]


def _valid_ideas(items):
    ideas = {}
    for item in items if isinstance(items, list) else []:
        if not isinstance(item, dict):
            continue
        fields = {name: ' '.join(item[name].split()) for name in _FIELD_LIMITS
                  if isinstance(item.get(name), str)}
        if not all(0 < len(fields.get(name, '')) <= limit and fields[name].isprintable()
                   for name, limit in _FIELD_LIMITS.items()):
            continue
        title_key = ''.join(char for char in fields['title'].casefold() if char.isalnum())
        if title_key:
            ideas.setdefault('idea-' + title_key, fields)
    return ideas


def load_ideas(path):
    """Show saved ideas newest first, with the starter ideas always available."""
    return {**_valid_ideas(read_json(path, [])), **_valid_ideas(_STARTER_IDEAS)}


def save_generated_ideas(path, response):
    """Keep up to three new ideas, merging with the latest saved list."""
    proposed = _valid_ideas(response.get('ideas') if isinstance(response, dict) else None)
    if not proposed:
        raise ValueError('No usable feature ideas in the model response')
    starters = _valid_ideas(_STARTER_IDEAS)
    added = 0

    def merge(saved):
        nonlocal added
        existing = _valid_ideas(saved)
        fresh = [idea for key, idea in proposed.items() if key not in existing and key not in starters][:3]
        added = len(fresh)
        return [*fresh, *existing.values()]

    saved = update_json(path, [], merge)
    return {**_valid_ideas(saved), **starters}, added


def idea_messages(ideas):
    """Give the local planning model product context and recent idea titles."""
    titles = dict.fromkeys(idea['title'] for idea in [*_STARTER_IDEAS, *list(ideas.values())[:20]])
    return [
        {'role': 'system', 'content': (
            'You suggest small, practical new features for EDIE, a local desktop AI assistant. '
            'Return a JSON object with an ideas array of three objects. Each must have four plain-English '
            'string fields: title, why, how, benefit. Keep the title under 80 characters and give '
            'one or two sentences for each other field. Explain the user need, a concrete way to build '
            'and check the feature, and what it could make easier. Keep existing permissions and human '
            'approval in effect. Treat supplied titles as reference data. Return only the JSON object.'
        )},
        {'role': 'user', 'content': (
            'EDIE already has Ollama chat, configurable models, a picker for saved Prompt Laboratory '
            'templates in the chat composer, profile memory, '
            'Knowledge Vault with source change checks and selected file refresh, research with sources, voice, task queues, '
            'Mission Control with approved steps, diagnostics, and a Self-Improvement Centre with '
            'code findings and tested proposals. Suggest three specific user-facing additions to this app. '
            'Focus on changes to an existing workspace that can be tested on their own. Exclude existing '
            'features, code cleanups, and variants of these ideas:\n' + json.dumps(list(titles), ensure_ascii=False)
        )},
    ]
