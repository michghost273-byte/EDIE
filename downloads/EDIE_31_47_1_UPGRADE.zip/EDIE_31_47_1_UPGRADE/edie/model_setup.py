"""Explicit, checksum-pinned Vosk installation through EDIE's main interpreter."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import secrets
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile

MODEL_NAME = 'vosk-model-small-en-us-0.15'
MODEL_URL = 'https://alphacephei.com/vosk/models/' + MODEL_NAME + '.zip'
MODEL_SHA256 = '30f26242c4eb449f948e42cb302dd7a686cb29a3423a8367f99ff41780942498'
MAX_DOWNLOAD = 60 * 1024 * 1024
MAX_EXPANDED = 256 * 1024 * 1024


def safe_extract(archive_path, destination, expected_root=MODEL_NAME):
    destination = Path(destination).resolve()
    with zipfile.ZipFile(archive_path) as archive:
        infos = archive.infolist()
        if len(infos) > 5000:
            raise ValueError('Model archive contains too many files')
        total, names = 0, set()
        for info in infos:
            name = info.filename.rstrip('/')
            member = PurePosixPath(name)
            if (not name or '\\' in name or ':' in name or member.is_absolute() or '..' in member.parts
                    or member.parts[0] != expected_root or name in names):
                raise ValueError('Model archive contains an unsafe or duplicate path')
            if (info.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError('Model archive cannot contain symbolic links')
            names.add(name)
            total += info.file_size
            if total > MAX_EXPANDED or info.file_size > MAX_EXPANDED:
                raise ValueError('Model archive exceeds extraction limits')
        for info in infos:
            output = destination.joinpath(*PurePosixPath(info.filename).parts)
            if info.is_dir():
                output.mkdir(parents=True, exist_ok=True)
            else:
                output.parent.mkdir(parents=True, exist_ok=True)
                with output.open('xb') as handle, archive.open(info) as source:
                    shutil.copyfileobj(source, handle)
    model = destination / expected_root
    for required in ('am/final.mdl', 'conf/model.conf', 'graph/HCLr.fst'):
        if not (model / required).is_file():
            raise ValueError('Model archive is missing ' + required)
    return model


def install(data_dir, application_dir, install_dependencies=True):
    if install_dependencies:
        requirements = Path(application_dir) / 'requirements-voice-wake.txt'
        print('Installing wake-word dependencies into:', sys.executable, flush=True)
        subprocess.run([sys.executable, '-m', 'pip', 'install', '--disable-pip-version-check', '-r', str(requirements)],
                       check=True, timeout=600)
    target_root = Path(data_dir).resolve() / 'voice_models'
    target_root.mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(target_root).free < 350 * 1024 * 1024:
        raise OSError('At least 350 MiB of free disk space is required to prepare this model.')
    with tempfile.TemporaryDirectory(prefix='edie-vosk-', dir=target_root) as temporary:
        temporary = Path(temporary)
        archive_path = temporary / 'model.zip'
        digest = hashlib.sha256()
        size = 0
        print('Downloading the official English Vosk model (about 40 MiB)…', flush=True)
        with urllib.request.urlopen(MODEL_URL, timeout=60) as response, archive_path.open('xb') as handle:
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                size += len(block)
                if size > MAX_DOWNLOAD:
                    raise ValueError('Model download exceeded the expected maximum size')
                digest.update(block)
                handle.write(block)
        if digest.hexdigest() != MODEL_SHA256:
            raise ValueError('The model checksum does not match this EDIE release. The download was not installed.')
        model = safe_extract(archive_path, temporary / 'extracted')
        (model / '.edie-model.json').write_text(json.dumps({'model': MODEL_NAME, 'archive_sha256': MODEL_SHA256,
            'installed_at': datetime.now(timezone.utc).isoformat()}, indent=2), encoding='utf-8')
        target = target_root / MODEL_NAME
        previous = None
        if target.exists():
            previous = target_root / (MODEL_NAME + '.previous-' + secrets.token_hex(4))
            target.rename(previous)
        try:
            model.rename(target)
        except Exception:
            if previous:
                previous.rename(target)
            raise
    print('Verified model installed to:', target, flush=True)
    print('Restart EDIE and enable wake listening in its existing Voice controls.', flush=True)
    return target
