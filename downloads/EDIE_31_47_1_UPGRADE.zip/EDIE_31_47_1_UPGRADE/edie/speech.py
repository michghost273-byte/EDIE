"""Interruptible local speech worker; SAPI remains on its owning thread."""
from __future__ import annotations

from collections import deque
import html
import json
import queue
import re
import sys
import threading
import time

from .audio import emit, watch_parent


def speech_chunks(text, limit=500):
    text = re.sub(r'```.*?```', ' ', str(text or ''), flags=re.S)
    text = re.sub(r'`([^`]*)`', r'\1', text)
    text = re.sub(r'!?\[([^\]]*)\]\([^)]+\)', r'\1', text)
    text = re.sub(r'[#>*_~]', '', text)
    text = re.sub(r'\s+', ' ', html.unescape(text)).strip()
    while text:
        if len(text) <= limit:
            yield text
            break
        boundaries = list(re.finditer(r'[.!?](?:\s+|$)', text[:limit + 1]))
        cut = boundaries[-1].end() if boundaries else text.rfind(' ', 0, limit + 1)
        if cut < limit // 3:
            cut = limit
        yield text[:cut].strip()
        text = text[cut:].lstrip()


class SpeechStream:
    """Track Markdown fences even when three backticks arrive in separate tokens."""
    def __init__(self):
        self.in_code = False
        self.ticks = 0
        self.buffer = ''

    def feed(self, text):
        for character in str(text):
            if character == '`':
                self.ticks += 1
                continue
            if self.ticks:
                if self.ticks // 3 % 2:
                    self.in_code = not self.in_code
                    if not self.in_code:
                        self.buffer += ' '
                self.ticks = 0
            if not self.in_code:
                self.buffer += character
        chunks = []
        while self.buffer:
            boundary = re.search(r'[.!?](?:\s+|$)|\n+', self.buffer)
            if boundary and boundary.end() >= 12:
                cut = boundary.end()
            elif len(self.buffer) > 480:
                cut = self.buffer.rfind(' ', 0, 460)
                if cut < 100:
                    cut = 460
            else:
                break
            chunks.extend(speech_chunks(self.buffer[:cut]))
            self.buffer = self.buffer[cut:]
        return chunks

    def finish(self):
        chunks = list(speech_chunks(self.buffer))
        self.buffer = ''
        self.ticks = 0
        self.in_code = False
        return chunks


def main():
    stop = threading.Event()
    commands = queue.Queue(maxsize=64)
    def reader():
        try:
            while not stop.is_set():
                line = sys.stdin.readline(32769)
                if not line:
                    break
                if len(line) > 32768:
                    emit('error', message='Oversized speech command rejected.')
                    break
                try:
                    value = json.loads(line)
                except ValueError:
                    continue
                if not isinstance(value, dict):
                    continue
                if value.get('type') == 'stop':
                    break
                # Never block the control channel behind queued speech.
                if value.get('type') == 'cancel':
                    while True:
                        try: commands.get_nowait()
                        except queue.Empty: break
                try:
                    commands.put_nowait(value)
                except queue.Full:
                    emit('error', message='Speech queue is full; remaining speech was rejected.',
                         id=str(value.get('id', ''))[:80], generation=value.get('generation', 0))
        finally:
            stop.set()
    threading.Thread(target=reader, daemon=True, name='EDIE-Speech-Control').start()
    threading.Thread(target=watch_parent, args=(stop,), daemon=True).start()
    engine = None
    try:
        import pyttsx3
        engine = pyttsx3.init(driverName='sapi5') if sys.platform == 'win32' else pyttsx3.init()
        pending = deque(maxlen=32)
        active = None
        finished = False
        def done(name, completed):
            nonlocal finished
            if active and name == active['id']:
                finished = True
        engine.connect('finished-utterance', done)
        engine.startLoop(False)
        emit('ready', status='LOCAL SPEECH READY')
        while not stop.is_set():
            for _ in range(64):
                try: item = commands.get_nowait()
                except queue.Empty: break
                kind = item.get('type')
                if kind == 'cancel':
                    engine.stop()
                    pending.clear()
                    active = None
                    finished = False
                    emit('cancelled', generation=item.get('generation', 0))
                elif kind == 'speak':
                    if len(pending) >= pending.maxlen:
                        emit('error', message='Speech queue is full.', id=str(item.get('id', ''))[:80],
                             generation=item.get('generation', 0))
                    elif isinstance(item.get('text'), str) and item['text'].strip():
                        pending.append(item)
            if finished and active:
                emit('finished', id=active['id'], generation=active.get('generation', 0))
                active, finished = None, False
            if active is None and pending:
                item = pending.popleft()
                try:
                    rate = max(110, min(240, int(item.get('rate', 178))))
                    volume = max(0, min(1, float(item.get('volume', .85))))
                    engine.setProperty('rate', rate)
                    engine.setProperty('volume', volume)
                    if isinstance(item.get('voice'), str) and item['voice']:
                        engine.setProperty('voice', item['voice'])
                    item['id'] = str(item.get('id') or time.monotonic_ns())[:80]
                    active = item
                    emit('started', id=item['id'], generation=item.get('generation', 0))
                    engine.say(item['text'][:1000], item['id'])
                except Exception as exc:
                    emit('error', message=type(exc).__name__ + ': ' + str(exc)[:240],
                         id=str(item.get('id', '')), generation=item.get('generation', 0))
                    active = None
            engine.iterate()
            stop.wait(.01)
        return 0
    except Exception as exc:
        emit('error', message=type(exc).__name__ + ': ' + str(exc)[:600])
        return 1
    finally:
        stop.set()
        if engine:
            try:
                engine.stop()
                engine.endLoop()
            except Exception:
                pass
