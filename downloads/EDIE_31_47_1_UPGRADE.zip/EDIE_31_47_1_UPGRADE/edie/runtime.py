"""Explicit ownership of new UI dispatch, draft recovery and error reporting."""
from __future__ import annotations

from collections import deque
import itertools
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
import queue
import threading
import time

from .metadata import VERSION
from .persistence import read_json, update_json


class UIDispatcher:
    """Let old worker callbacks schedule Tk work without calling Tcl off-thread."""
    def __init__(self, root, capacity=2048, interval_ms=25):
        self.root, self.capacity, self.interval_ms = root, capacity, interval_ms
        self.owner = threading.get_ident()
        self.original_after = root.after
        self.original_cancel = root.after_cancel
        self.items = queue.Queue(maxsize=capacity)
        self.serial = itertools.count()
        self.ids = {}
        self.cancelled = set()
        self.lock = threading.RLock()
        self.closed = False
        self.pump_id = None
        self.dropped = 0

    def install(self):
        self.root.after = self.after
        self.root.after_cancel = self.cancel
        self.pump_id = self.original_after(self.interval_ms, self._pump)
        return self

    def after(self, delay, callback=None, *args):
        if self.closed:
            raise RuntimeError('EDIE is closing')
        if threading.get_ident() == self.owner:
            return self.original_after(delay, callback, *args)
        if not callable(callback):
            raise RuntimeError('A worker must schedule a callable UI action')
        identifier = 'edie-ui-' + str(next(self.serial))
        try:
            self.items.put_nowait(('schedule', identifier, int(delay), callback, args))
        except queue.Full as exc:
            self.dropped += 1
            raise RuntimeError('EDIE UI callback queue is full') from exc
        return identifier

    def cancel(self, identifier):
        if self.closed:
            return
        if str(identifier).startswith('edie-ui-'):
            with self.lock:
                self.cancelled.add(identifier)
        elif threading.get_ident() == self.owner:
            return self.original_cancel(identifier)
        else:
            try:
                self.items.put_nowait(('cancel', identifier, 0, None, ()))
            except queue.Full:
                self.dropped += 1

    def _pump(self):
        if self.closed:
            return
        deadline = time.monotonic() + .008
        with self.lock:
            for identifier in list(self.cancelled):
                actual = self.ids.pop(identifier, None)
                if actual is not None:
                    try: self.original_cancel(actual)
                    except Exception: pass
                    self.cancelled.discard(identifier)
        for _ in range(128):
            if time.monotonic() >= deadline:
                break
            try: kind, identifier, delay, callback, args = self.items.get_nowait()
            except queue.Empty: break
            if kind == 'cancel':
                try: self.original_cancel(identifier)
                except Exception: pass
                continue
            with self.lock:
                if identifier in self.cancelled:
                    self.cancelled.discard(identifier)
                    continue
            def run(identifier=identifier, callback=callback, args=args):
                with self.lock:
                    self.ids.pop(identifier, None)
                    cancelled = identifier in self.cancelled
                    self.cancelled.discard(identifier)
                if not self.closed and not cancelled:
                    callback(*args)
            self.ids[identifier] = self.original_after(max(0, delay), run)
        self.pump_id = self.original_after(self.interval_ms, self._pump)

    def close(self):
        if self.closed:
            return
        self.closed = True
        for identifier in [self.pump_id, *self.ids.values()]:
            if identifier is not None:
                try: self.original_cancel(identifier)
                except Exception: pass
        self.ids.clear()
        self.cancelled.clear()


class ApplicationServices:
    """New services have one start/close boundary, independent of legacy wrappers."""
    def __init__(self, app, root, data_dir, environment=None):
        self.app, self.root, self.data = app, root, Path(data_dir)
        self.environment = environment or {}
        self.dispatcher = UIDispatcher(root).install()
        self.closed = False
        self.started_at = time.monotonic()
        self.draft_id = None
        self.last_draft = None
        self.metrics = deque(maxlen=200)
        self.processes = set()
        self.process_lock = threading.RLock()
        self.log = logging.getLogger('EDIE.reliability.' + str(id(self)))
        self.log.propagate = False
        self.log.setLevel(logging.WARNING)
        self.handler = None
        try:
            self.data.mkdir(parents=True, exist_ok=True)
            self.handler = RotatingFileHandler(self.data / 'edie_errors.log', maxBytes=262144,
                                               backupCount=2, encoding='utf-8', delay=True)
            self.handler.setFormatter(logging.Formatter('%(asctime)s %(message)s'))
            self.log.addHandler(self.handler)
        except OSError:
            pass
        self.previous_exception_handler = getattr(root, 'report_callback_exception', None)
        root.report_callback_exception = self.report_ui_exception
        root.bind('<Destroy>', self._destroy, add='+')

    @property
    def profile(self):
        return str(getattr(self.app, 'active_profile', 'Default'))

    def report_ui_exception(self, exception_type, value, traceback):
        # Fixed labels and exception types only: do not log user text or secrets.
        self.log.warning('UI callback failed: %s', exception_type.__name__)
        try:
            self.app.status.set('A screen action failed (' + exception_type.__name__ + '). Open Reliability for diagnostics.')
        except Exception:
            pass

    def ready(self):
        from .control_panel import install_navigation
        install_navigation(self.app)
        self.root.after(500, self._restore_draft)
        self.draft_id = self.root.after(3000, self._save_draft)

    def _draft_text(self):
        if getattr(self.app, '_placeholder_active', False):
            return ''
        return self.app.input.get('1.0', 'end-1c')[:20000]

    def _save_draft(self, rearm=True):
        if self.closed:
            return
        try:
            draft = self._draft_text()
            state = (self.profile, draft)
            if state != self.last_draft:
                def update(body):
                    body[self.profile] = {'text': draft, 'saved_at': int(time.time())}
                    return body
                update_json(self.data / 'unsent_drafts.json', {}, update)
                self.last_draft = state
        except Exception as exc:
            self.log.warning('Draft save failed: %s', type(exc).__name__)
        if rearm and not self.closed:
            self.draft_id = self.root.after(3000, self._save_draft)

    def _restore_draft(self):
        if self.closed:
            return
        try:
            body = read_json(self.data / 'unsent_drafts.json', {})
            saved = body.get(self.profile, {})
            text = saved.get('text', '') if isinstance(saved, dict) else ''
            if isinstance(text, str) and text and not self._draft_text() and not self.app.busy:
                self.app.input.delete('1.0', 'end')
                self.app.input.insert('1.0', text[:20000])
                self.app._placeholder_active = False
                self.app.status.set('Restored an unsent draft. Review it before sending.')
        except Exception as exc:
            self.log.warning('Draft recovery failed: %s', type(exc).__name__)

    def record_chat(self, request_id, started, first_chunk=None):
        self.metrics.append({'request': str(request_id)[:60],
                             'elapsed_ms': round((time.monotonic() - started) * 1000),
                             'first_chunk_ms': round((first_chunk - started) * 1000) if first_chunk else None})

    def run_process(self, command, **options):
        import subprocess
        with self.process_lock:
            if self.closed:
                raise RuntimeError('EDIE is closing')
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **options)
            self.processes.add(process)
        try:
            stdout, stderr = process.communicate(timeout=900)
            if process.returncode:
                raise RuntimeError('Model setup failed. ' + stderr.decode('utf-8', 'replace')[-900:])
            return stdout.decode('utf-8', 'replace')[-4000:]
        finally:
            if process.poll() is None:
                process.terminate()
                try: process.wait(timeout=2)
                except subprocess.TimeoutExpired: process.kill(); process.wait()
            with self.process_lock:
                self.processes.discard(process)

    def status(self):
        return {'version': VERSION, 'ui_queue': self.dispatcher.items.qsize(),
                'rejected_callbacks': self.dispatcher.dropped,
                'recent_chat_timings': list(self.metrics)[-20:],
                'draft_recovery': 'Unsent text only; never automatically sent.',
                'error_log': str(self.data / 'edie_errors.log')}

    def _destroy(self, event):
        if event.widget is self.root:
            self.close()

    def close(self):
        if self.closed:
            return
        self._save_draft(rearm=False)
        self.closed = True
        if self.draft_id is not None:
            try: self.root.after_cancel(self.draft_id)
            except Exception: pass
        self.dispatcher.close()
        from .processes import stop_process
        for name in ('_duplex_tts_process', '_duplex_process', '_live_audio_process'):
            stop_process(getattr(self.app, name, None))
        with self.process_lock:
            for process in self.processes:
                try: process.terminate()
                except OSError: pass
        if self.handler:
            self.handler.close()
            self.log.removeHandler(self.handler)
