"""EDIE services shared by the desktop application and isolated voice workers."""
from .metadata import VERSION

__version__ = VERSION
