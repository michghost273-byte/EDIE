#!/usr/bin/env python3
"""EDIE verified worker entry point. Audio stays in RAM; no recordings are saved."""
import os
import sys
from pathlib import Path
sys.path.insert(0, os.environ.get('EDIE_APP_DIR', str(Path(__file__).resolve().parent)))
from edie.speech import main
if __name__ == '__main__':
    raise SystemExit(main())
