#!/usr/bin/env python3
"""Compatibility entry point for existing EDIE shortcuts. Starts the 31.47 upgrade."""
from EDIE import main
if __name__ == '__main__':
    raise SystemExit(main())
