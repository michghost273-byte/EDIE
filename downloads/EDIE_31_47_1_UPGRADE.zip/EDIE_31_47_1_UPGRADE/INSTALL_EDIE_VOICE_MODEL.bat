@echo off
echo EDIE local wake-word setup
echo This installs pinned Vosk dependencies and the checksum-verified English model.
echo It uses the same configured Python and data directory as START_EDIE.bat.
call "%~dp0START_EDIE.bat" --install-voice-model
if errorlevel 1 exit /b %errorlevel%
pause
