@echo off
call "%~dp0START_EDIE.bat" --self-test
if errorlevel 1 exit /b %errorlevel%
echo.
echo EDIE checks completed. Live Windows devices still need a manual test.
pause
