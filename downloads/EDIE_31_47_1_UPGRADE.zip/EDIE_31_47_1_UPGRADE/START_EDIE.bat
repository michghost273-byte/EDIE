@echo off
setlocal
cd /d "%~dp0"
title EDIE 31.47.1 - Reliability and Voice
if not exist "EDIE.py" (
  echo EDIE files are missing. Extract the complete ZIP first.
  pause
  exit /b 1
)
if defined EDIE_PYTHON (
  if not exist "%EDIE_PYTHON%" (
    echo EDIE_PYTHON must point to an existing Python executable.
    pause
    exit /b 1
  )
  "%EDIE_PYTHON%" "EDIE.py" %*
  goto :done
)
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" "EDIE.py" %*
  goto :done
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3 "EDIE.py" %*
  goto :done
)
where python >nul 2>nul
if not errorlevel 1 (
  python "EDIE.py" %*
  goto :done
)
echo Python 3.11 or newer was not found. Install Python with Tcl/Tk support.
pause
exit /b 1
:done
set "EDIE_EXIT=%errorlevel%"
if not "%EDIE_EXIT%"=="0" (
  echo.
  echo EDIE could not complete the action. Read the message above.
  pause
)
exit /b %EDIE_EXIT%
