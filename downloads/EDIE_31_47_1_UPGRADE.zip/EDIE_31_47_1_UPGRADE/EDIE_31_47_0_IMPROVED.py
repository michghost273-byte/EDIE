#!/usr/bin/env python3
"""Compatibility launcher for EDIE 31.47.0 shortcuts; starts the corrected release."""
from EDIE import main
if __name__ == '__main__':
    raise SystemExit(main())
