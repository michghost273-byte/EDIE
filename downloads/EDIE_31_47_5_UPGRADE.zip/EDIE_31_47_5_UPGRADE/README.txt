EDIE 31.47.5 — Stronger local model

Extract the COMPLETE ZIP into a new folder. Keep the previous folder intact.
Copy the old edie_data folder into the new folder BEFORE the first launch.
If EDIE_DATA_DIR is set, point it to a copy for an isolated trial.

Double-click START_EDIE.bat. Python 3.11+ with Tcl/Tk and Ollama are required.
Open EDIE > Voice and reliability, or press Ctrl+Shift+R, for the new controls.

Read README.md for setup, voice preparation, privacy, backups and rollback.
IMPROVEMENTS.md tracks all 100 suggestions and distinguishes completed changes
from partial improvements and future work. VALIDATION.md records actual checks.

Run CHECK_EDIE.bat for isolated tests. Windows audio and device behaviour still
need a real Windows test. This is portable Python source, not a signed installer.
Keep edie/, assets/ and all worker scripts with the launcher.

31.47.1 fixes the Windows self-test SQLite file-lock error. See CHANGELOG.md.
